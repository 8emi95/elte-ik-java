package tests;

import render.shape.Point;
import render.shape.Point3D;
import render.shape.Triangle;
import render.space.BaseSpace;
import render.space.Plane;
import render.space.Space;
import render.util.Color;
import utest.Test;
import utest.Testable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part3SpaceTest extends Testable {
    @Override
    public void assertion() throws Exception {
        check("Az Space nem terjeszti ki a BaseClasst.",getSuperClass(className())==BaseSpace.class);
        List<Point3D> pl = new ArrayList<Point3D>();
        Point3D p = new Point3D(1,1,3);
        Point3D p3 = new Point3D(2,3,3);

        Point3D p2 = new Point3D(2,2,3);

        pl.add(p2);
        pl.add(p);
        pl.add(p3);
        Triangle<Point3D> t = new Triangle(pl, Color.BLUE);
        Triangle<Point3D> t2 = new Triangle(pl,Color.BLUE);
        Space s = new Space();
        check("BaseSpace.getTriangleCount nem mukodik megfeleloen", s.getTriangleCount()==0);

        s.addTriangle(t);
        s.addTriangle(t);

        check("BaseSpace.addTriangle nem hajtódott megfelelően végre", s.getTriangleCount()==1);
        check("BaseSpace.addTriangle nem hajtódott megfelelően végre. Az Triangle egyenloseg definicioja szerint nem kellett volna hozzaadni.(Nezd meg a hashCode-ot esetleg!)", s.getTriangleCount()==1);
        s = Space.readModel("input.txt");
        check("A fájlból beolvasás nem hajtódott végre megfeleloen!", s.getTriangleCount()==3);
        boolean b1 = s.toString().replace(" ","").contains("TR[GREEN[ x = 1, y = 2, z = 3 ][ x = 4, y = 5, z = 6 ][ x = 7, y = 8, z = 9 ]]".replace(" ",""));
        boolean b2 = s.toString().replace(" ","").contains("TR[RED[ x = 0, y = 1, z = 2 ][ x = 3, y = 0, z = 0 ][ x = 3, y = 4, z = 5 ]]".replace(" ",""));
        boolean b3 = s.toString().replace(" ","").contains("TR[BLUE[ x = 1, y = 1, z = 5 ][ x = 2, y = 12, z = 24 ][ x = 6, y = -1, z = -1 ]]".replace(" ",""));
        check("A fájlból beolvasás nem hajtódott végre megfeleloen!", b1 && b2 && b3);

        Plane plane = s.project();
        b1 = plane.toString().replace(" ","").contains("TR[GREEN[ x = 1, y = 2][ x = 4, y = 5][ x = 7, y = 8]".replace(" ",""));
        b2 = plane.toString().replace(" ","").contains("TR[RED[ x = 0, y = 1][ x = 3, y = 0][ x = 3, y = 4]]".replace(" ",""));
        b3 = plane.toString().replace(" ","").contains("TR[BLUE[ x = 1, y = 1][ x = 2, y = 12][ x = 6, y = -1]]".replace(" ",""));
        check("A vetites nem hajtódott végre megfeleloen!", b1 && b2 && b3);


    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                constructor(className()),
                method(Plane.class,className() +".project"),
                optionalMethod(Point.class, className() + ".compareTo",Point.class),

                method(Space.class, className() + ".translate",int.class,int.class,int.class),
                optionalMethod(BaseSpace.class, className() + ".translate",int.class,int.class,int.class),
                staticMethod(Space.class,className()+".readModel",String.class)
        };

    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.space.Space";
    }

    @Override
    public int score() {
        return 4;
    }

    public static void main(String[] args) {
        Test.main(new Part3SpaceTest());
    }

}

