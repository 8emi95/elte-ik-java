package tests;

import utest.Tester;

/**
 * Ez a tesztelo lefuttatja a tests.part1 csomagban talalhato teszteket.
 */
public class Part1 extends Tester {

	public static int runAll() {
		int total = 0;
		total += run(Part1PointTest.class.getName()).score;
		total += run(Part1Point3DTest.class.getName()).score;
		total += run(Part1ColorTest.class.getName()).score;
		total += run(Part1PointComparableTest.class.getName()).score;
		total += run(Part1Point3DComparableTest.class.getName()).score;
		return total;
	}
	
	public static void main(String[] args) {
		int score = runAll();
		System.out.println("Part1 pontszam: " + score + " + ?");
		System.out.println("(A pluszpontokat az oktato meri fel, es az alappontokat is felulbiralhatja.)");
	}

}