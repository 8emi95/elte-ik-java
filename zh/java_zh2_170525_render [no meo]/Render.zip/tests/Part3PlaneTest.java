package tests;

import java.util.ArrayList;
import java.util.List;

import render.shape.Point;
import render.shape.Triangle;
import render.space.BaseSpace;
import render.space.Plane;
import render.space.Space;
import render.util.Color;
import utest.Test;
import utest.Testable;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part3PlaneTest extends Testable {
    @Override
    public void assertion() throws Exception {
        check("Az Plane nem terjeszti ki a BaseSpace-t.",getSuperClass(className())==BaseSpace.class);
        List<Point> pl = new ArrayList<>();
        Point p = new Point(1,1);
        Point p3 = new Point(2,3);

        Point p2 = new Point(2,2);

        pl.add(p2);
        pl.add(p);
        pl.add(p3);
        Triangle<Point> t = new Triangle(pl, Color.BLUE);
        Triangle<Point> t2 = new Triangle(pl,Color.BLUE);
        Plane s = new Plane();
        check("BaseSpace.getTriangleCount nem mukodik megfeleloen", s.getTriangleCount()==0);
        s.addTriangle(t);
        s.addTriangle(t);


        check("BaseSpace.addTriangle nem hajtódott megfelelően végre", s.getTriangleCount()==1);
        check("BaseSpace.addTriangle nem hajtódott megfelelően végre. Az Triangle egyenloseg definicioja szerint nem kellett volna hozzaadni.(Nezd meg a hashCode-ot esetleg!)", s.getTriangleCount()==1);
        boolean b3 = s.toString().replace(" ","").contains("TR[BLUE[ x = 1, y = 1 ][ x = 2, y = 2 ][ x = 2, y = 3 ]]".replace(" ",""));
        check("A toString nem mukodik megfeleloen!",  b3);





    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                optionalMethod(Point.class, className() + ".compareTo",Point.class),
                optionalMethod(String.class, className() + ".toString"),
        		optionalConstructor(className()),
                method(Plane.class, className() + ".translate",int.class,int.class,int.class),
                optionalMethod(BaseSpace.class, className() + ".translate",int.class,int.class,int.class),
                method(Void.TYPE,className()+".writeToFile",String.class)
        };

    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.space.Plane";
    }

    @Override
    public int score() {
        return 3;
    }

    public static void main(String[] args) {
        Test.main(new Part3PlaneTest());
    }

}

