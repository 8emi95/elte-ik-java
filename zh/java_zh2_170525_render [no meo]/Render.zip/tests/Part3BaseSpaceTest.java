package tests;

import render.shape.Point;
import render.shape.Triangle;
import render.space.BaseSpace;
import render.util.Color;
import utest.Test;
import utest.Testable;

import java.util.List;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part3BaseSpaceTest extends Testable {
    @Override
    public void assertion() throws Exception {
        check("Az BaseSpace nem absztrakt.",isAbstractClass(className()));

    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                constructor(className()),
                method(Void.TYPE, className() + ".addTriangle", Triangle.class),
                method(String.class, className() + ".toString"),
                method(BaseSpace.class, className() + ".translate",int.class,int.class,int.class),
                method(int.class, className() + ".getTriangleCount")
        };
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {
                field(className() + ".shapes")
        };
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.space.BaseSpace";
    }

    @Override
    public int score() {
        return 4;
    }

    public static void main(String[] args) {
        Test.main(new Part3BaseSpaceTest());
    }

}

