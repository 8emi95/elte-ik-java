package tests;

import render.shape.Point;
import render.shape.Point3D;
import utest.Test;
import utest.Testable;

/**
 * Created by peterkiss on 24/05/17.
 */
public class Part1Point3DTest extends Testable {
    @Override
    public void assertion() throws Exception {
        check("A Point3D nem terjeszti ki a Point osztályt.", getSuperClass( className())==(Point.class));
        Point3D p = new Point3D(0,0,0);
        //System.out.println(p.toString());
        check("Az objektum nem a megfelelo ertekekkel jott letre.", p.getX() == 0 && p.getY() == 0 && p.getZ() == 0);
        p.translate(1,1,1);
        check("A translate nem a megfelelo modon tolja el a pontot", p.getX() == 1 && p.getY() == 1 && p.getZ() == 1);
        Point3D p1 = p.makeCopy();
        check("A makeCopy nem hozott letre uj objektumot", p.getX() == 1 && p.getY() == 1 && p.getZ() == 1);
        Point point = p1.project();
        check("A project nem megfelelően vetíti le a pontot", point.getX() == 1 && point.getY() == 1);

    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                constructor(className(), int.class,int.class,int.class),
                method(String.class, className() + ".toString"),

                optionalMethod(int.class, className() + ".compareTo", Point.class),
                optionalMethod(boolean.class, className() + ".equals", Object.class),
                method(Point3D.class, className() + ".makeCopy"),
                optionalMethod(Point.class, className() + ".makeCopy"),

                optionalMethod(int.class, className() + ".hashCode"),
                optionalMethod(int.class, className() + ".compareTo", Object.class),

                method(Void.TYPE, className() + ".translate", int.class, int.class,int.class),
                optionalMethod(int.class, className() + ".getX"),
                optionalMethod(int.class, className() + ".getY"),
                method(Point.class, className() + ".project"),
                method(int.class, className() + ".getZ")

        };
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.shape.Point3D";
    }

    @Override
    public int score() {
        return 3;
    }

    public static void main(String[] args) {
        Test.main(new Part1Point3DTest());
    }

}
