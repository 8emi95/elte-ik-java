package tests;

import render.util.Color;
import utest.Test;
import utest.Testable;

import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part1ColorTest extends Testable {

    @Override
    public void assertion() throws Exception {

    }

    @Override
    public Object[] expectedMethods() throws Exception {
        Method[] baseMethods = Enum.class.getMethods();
        Object[] methods = Arrays.copyOfRange(baseMethods, 0, baseMethods.length + 4, Object[].class);
        methods[baseMethods.length] = method(Color[].class, className() + ".values");
        methods[baseMethods.length + 1] = method(Color.class, className() + ".valueOf", String.class);
        return methods;
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {
                staticField(className() + ".RED"),
                staticField(className() + ".GREEN"),
                staticField(className() + ".BLUE")
        };
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.util.Color";
    }

    @Override
    public int score() {
        return 1;
    }

    public static void main(String[] args) {
        Test.main(new Part1ColorTest());
    }

}
