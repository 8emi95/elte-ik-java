package tests;

import render.shape.Point;
import render.shape.Triangle;
import render.util.Color;
import utest.Test;
import utest.Testable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part2TriangleTest extends Testable{
    @Override
    public void assertion() throws Exception {

        List<Point> pl = new ArrayList<Point>();
        Point p = new Point(1,1);
        Point p3 = new Point(2,3);

        Point p2 = new Point(2,2);

        pl.add(p2);
        pl.add(p);
        pl.add(p3);
        Triangle<Point> t = new Triangle(pl,Color.BLUE);
        Triangle<Point> t2 = new Triangle(pl,Color.BLUE);


        check("Az objektum nem rendezve tárolja a pontokat.", t.getPoints().get(0).getX()==1 && t.getPoints().get(0).getY()==1);
        check("Az equals nem megfelelően működik 1.", t.equals(t2));
        check("A hashCode nem megfeleloen mukodik", t.hashCode()==t2.hashCode());

        pl.set(0,new Point(5,5));
        t2 = new Triangle(pl,Color.BLUE);
        check("Az equals nem megfelelően működik 2.", !t.equals(t2));


    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                constructor(className(), List.class, Color.class),
                method(String.class, className() + ".toString"),
                method(boolean.class, className() + ".equals",Object.class),
                method(List.class, className() + ".getPoints"),
                method(Color.class, className() + ".getColor"),
                method(int.class, className() + ".hashCode")
        };
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.shape.Triangle";
    }

    @Override
    public int score() {
        return 5;
    }

    public static void main(String[] args) {
        Test.main(new Part2TriangleTest());
    }

}
