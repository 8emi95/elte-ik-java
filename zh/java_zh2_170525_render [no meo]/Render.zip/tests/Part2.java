package tests;

import utest.Tester;

/**
 * Ez a tesztelo lefuttatja a tests.part2 csomagban talalhato teszteket.
 */
public class Part2 extends Tester {

	public static int runAll() {
		int total = 0;
		total += run(Part2TriangleTest.class.getName()).score;
		return total;
	}
	
	public static void main(String[] args) {
		int score = runAll();
		System.out.println("Part2 pontszam: " + score + " + ?");
		System.out.println("(A pluszpontokat az oktato meri fel, es az alappontokat is felulbiralhatja.)");
	}

}