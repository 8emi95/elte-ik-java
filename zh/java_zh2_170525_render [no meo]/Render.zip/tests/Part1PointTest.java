package tests;

import render.shape.Point;
import utest.Test;
import utest.Testable;

/**
 * Created by peterkiss on 24/05/17.
 */
public class Part1PointTest extends Testable{
    @Override
    public void assertion() throws Exception {
        Point p = new Point(0,0);
        check("Az objektum nem a megfelelo ertekekkel jott letre.", p.getX() == 0 && p.getY() == 0);
        p.translate(1,1);
        check("A translate nem a megfelelo modon tolja el a pontot", p.getX() == 1 && p.getY() == 1);
        Point p1 = p.makeCopy();
        p1.translate(1,1);
        check("A makeCopy nem hozott letre uj objektumot", p.getX() == 1 && p.getY() == 1);

    }

    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[] {
                constructor(className(), int.class,int.class),
                method(String.class, className() + ".toString"),
                method(Void.TYPE, className() + ".translate", int.class, int.class),
                method(int.class, className() + ".getX"),
                method(int.class, className() + ".getY"),
                method(Point.class, className() + ".makeCopy"),
                optionalMethod(int.class, className() + ".compareTo", Object.class), //????

                optionalMethod(int.class, className() + ".compareTo", Point.class),
                optionalMethod(boolean.class, className() + ".equals", Object.class),
                optionalMethod(int.class, className() + ".hashCode")


        };
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {
                optionalField(className()+".x"),
                optionalField(className()+".y")
        };
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.shape.Point";
    }

    @Override
    public int score() {
        return 3;
    }

    public static void main(String[] args) {
        Test.main(new Part1PointTest());
    }

}
