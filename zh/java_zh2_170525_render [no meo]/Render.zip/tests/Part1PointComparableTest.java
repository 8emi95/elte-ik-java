package tests;

import render.shape.Point;
import utest.Test;
import utest.Testable;

import java.util.Arrays;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part1PointComparableTest extends Testable{
    @Override
    public void assertion() throws Exception {
        //check("A Point nem terjeszti ki a Sender interfeszt.", doesImplementInterface(className(), Comparable.class));
        Point p1 = new Point(1,1);
        Point p2 = new Point(0,0);
        //System.out.println(p1.compareTo(p2));
        check("Az osszehasonlitas nem megfeleloen mukodik 1", p1.compareTo(p2)>=0);
        p2 = new Point(1,1);
        check("Az osszehasonlitas nem megfeleloen mukodik 2", p1.compareTo(p2)==0);
        check("Az equals nem megfeleloen mukodik 1", p1.equals(p2));
        check("A hashCode nem megfeleloen mukodik 1", p1.hashCode()==p2.hashCode());
        p2 = new Point(1,0);
        check("Az osszehasonlitas nem megfeleloen mukodik 3", p1.compareTo(p2)>=0);
        check("Az equals nem megfeleloen mukodik 2", !p1.equals(p2));
        p2 = new Point(1,2);
        check("Az osszehasonlitas nem megfeleloen mukodik 3", p1.compareTo(p2)<0);

    }

    @Override
    public Object[] expectedMethods() throws Exception {

        Object[] cm = new Part1PointTest().expectedMethods();
        cm =Arrays.copyOf(cm,cm.length+3);
        cm[cm.length-2]=method(int.class, className() + ".compareTo", Point.class);
        cm[cm.length-1]=method(boolean.class, className() + ".equals", Object.class);
        cm[cm.length-3]=method(int.class, className() + ".hashCode");

        return cm;
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {
                optionalField(className()+".x"),
                optionalField(className()+".y")
        };
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.shape.Point";
    }

    @Override
    public int score() {
        return 2;
    }

    public static void main(String[] args) {
        Test.main(new Part1PointComparableTest());
    }

}
