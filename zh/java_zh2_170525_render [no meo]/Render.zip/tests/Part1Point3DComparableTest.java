package tests;

import render.shape.Point;
import render.shape.Point3D;
import utest.Test;
import utest.Testable;

import java.util.Arrays;

/**
 * Created by peterkiss on 25/05/17.
 */
public class Part1Point3DComparableTest extends Testable{


    @Override
    public void assertion() throws Exception {
        check("A Point nem terjeszti ki a Sender interfeszt.", doesImplementInterface(className(), Comparable.class));
        Point3D p1 = new Point3D(1,1,1);
        Point3D p2 = new Point3D(0,0,0);
        check("Az osszehasonlitas nem megfeleloen mukodik 1", p1.compareTo(p2)>0);
        p2 = new Point3D(1,1,1);
        check("Az osszehasonlitas nem megfeleloen mukodik 2", p1.compareTo(p2)==0);
        check("Az equals nem megfeleloen mukodik 1", p1.equals(p2));
        check("A hashCode nem megfeleloen mukodik", p1.hashCode()==p2.hashCode());

        p2 = new Point3D(1,0,0);
        check("Az osszehasonlitas nem megfeleloen mukodik 3", p1.compareTo(p2)>0);
        check("Az equals nem megfeleloen mukodik 2", !p1.equals(p2));
        p2 = new Point3D(1,1,2);
        check("Az osszehasonlitas nem megfeleloen mukodik 3", p1.compareTo(p2)<0);

    }

    @Override
    public Object[] expectedMethods() throws Exception {

        Object[] cm = new Part1Point3DTest().expectedMethods();
        cm = Arrays.copyOf(cm,cm.length+3);
        cm[cm.length-2]=method(int.class, className() + ".compareTo", Point.class);
        cm[cm.length-1]=method(boolean.class, className() + ".equals", Object.class);
        cm[cm.length-3]=method(int.class, className() + ".hashCode");

        return cm;
    }

    @Override
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    @Override
    public String description() {
        return getClass().getName();
    }

    @Override
    public String className() {
        return "render.shape.Point3D";
    }

    @Override
    public int score() {
        return 2;
    }

    public static void main(String[] args) {
        Test.main(new Part1Point3DComparableTest());
    }



}
