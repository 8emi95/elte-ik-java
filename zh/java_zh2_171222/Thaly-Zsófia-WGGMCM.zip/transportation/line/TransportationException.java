package transportation.line;

public class TransportationException extends Exception {
	public TransportationException(String message) {
		super(message);
	}
}