package graph.undirected;
import graph.Graph;

public class UndirectedGraph<V> implements Graph{
	
}