package hu.elte.inf.pnyf.whisperity.tester;

import java.util.StringJoiner;

class TestRun implements Dispatchable {
  final Tester testerObject;
  Status status;
  Throwable failureReason;
  final TestEnvironment environment;
  
  TestRun(Tester t, TestEnvironment env) {
    testerObject = t;
    environment = env;
    status = Status.UNASSIGNED;
  }
  
  public void dispatch() {
    if (status == Status.SKIPPED || status == Status.FINISHED || status == Status.FAILED)
      return;
    
    // Initially, we want to check for all dependencies to see if they are finished
    if (status == Status.UNASSIGNED) {
      status = Status.WAIT_DEPENDENCIES;
      checkDependencies();
    } else if (status == Status.WAIT_DEPENDENCIES) {
      checkDependencies();
    }
    
    // If after checking we are still waiting for dependencies, the test case could not be ran right now
    if (status == Status.WAIT_DEPENDENCIES) {
      return;
    } else if (status == Status.RUNNING) {
      // If not, it is either running (because dependencies were successfully ran) or some dependency failed
      
      testerObject.setup();
      
      try {
        testerObject.runTests();
      } catch (TestCaseException tce) {
        failureReason = tce;
        status = Status.FAILED;
        return;
      } catch (java.lang.NoClassDefFoundError ncdfe) {
        failureReason = ncdfe;
        status = Status.SKIPPED;
        return;
      } catch (java.lang.NoSuchMethodError nsme) {
        failureReason = nsme;
        status = Status.SKIPPED;
        return;
      } finally {
        testerObject.teardown();
      }
      
      status = Status.FINISHED;
    }
  }
  
  private void checkDependencies() {
    TestEnvironment.DependencyResultSet drs = environment.checkDependenciesFor(this);
    
    if (drs.rest.size() != 0)
      return; // If any dependency is unresolved so far, don't do anything with the current check.
    
    if (drs.greenlight) {
      status = Status.RUNNING; // If greenlight, we enable running the test suite
    } else {
      /*StringJoiner sjSucc = new StringJoiner(", ");
      for (TestRun dep : drs.successful) {
        sjSucc.add(dep.testerObject.suiteName);
      }*/
      
      StringJoiner sjSkip = new StringJoiner(", ");
      for (TestRun dep : drs.skipped) {
        sjSkip.add(dep.testerObject.suiteName);
      }
      
      StringJoiner sjFail = new StringJoiner(", ");
      for (TestRun dep : drs.failed) {
        sjFail.add(dep.testerObject.suiteName);
      }
      
      StringBuilder sb = new StringBuilder();
      sb.append("A tesztegység '" + testerObject.suiteName + "' nem futtatható, mivel ");
      if (drs.failed.size() > 0) {
        sb.append("\n\tAz alábbi függőség tesztegységek MEGBUKTAK: " + sjFail.toString());
      }
      
      if (drs.skipped.size() > 0) {
        sb.append("\n\tAz alábbi függőség tesztegységek KIHAGYASRA KERULTEK: " + sjSkip.toString());
      }
      
      /*if (drs.successful.size() > 0) {
        sb.append("\n\tAz alábbi függőség tesztegységek SIKERESEN LEFUTOTTAK: " + sjSucc.toString());
      }*/
      
      // Set state. If there is any failure, we fail, if there is any skip, we skip
      if (drs.failed.size() > 0) {
        status = Status.FAILED;
      } else if (drs.skipped.size() > 0) {
        status = Status.SKIPPED;
      }
      
      failureReason = new IllegalStateException(sb.toString());
    }
  }
}