package hu.elte.inf.pnyf.whisperity.tester;

public class GradedTestCase extends TestCase {
  public int points;
  
  public GradedTestCase(String caseName, Dispatchable action, int value) {
    name = caseName;
    dispatch = action;
    points = value;
  }
}