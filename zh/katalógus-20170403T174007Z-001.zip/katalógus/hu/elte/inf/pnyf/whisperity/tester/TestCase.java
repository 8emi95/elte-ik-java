package hu.elte.inf.pnyf.whisperity.tester;

public abstract class TestCase {
  public String name;
  public Dispatchable dispatch;
}