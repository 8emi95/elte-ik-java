package hu.elte.inf.pnyf.whisperity.tester;

import java.util.ArrayList;

public class GradingTestEnvironment extends TestEnvironment {
  private ArrayList<Integer> gradeBorders = new ArrayList<Integer>(5);
  private int currentPoints;
  
  public GradingTestEnvironment(int initialPoints) {
    currentPoints = initialPoints;
  }
  
  @Override
  protected void before() {
    return;
  }
  
  @Override
  public void runTestCase(TestCase tc) {
    try {
      if (!tc.getClass().equals(Class.forName("hu.elte.inf.pnyf.whisperity.tester.GradedTestCase")))
        throw new UnsupportedOperationException("A graded environment requires a gradable test case to be ran.");
    } catch (java.lang.ClassNotFoundException cnfs) {
      assert false; return; // This shouldn't really happen if the tester was not tampered with.
    }
    
    System.out.print("\tTeszteset ");
    if (tc.name != null)
      System.out.print(tc.name + " ");
    System.out.print("futtatása...");
    
    TestCaseException error = null;
    try {
      tc.dispatch.dispatch();
    } catch (TestCaseException e) {
      //error = new TestCaseException("Teszteset " + tc.name + " futtatása során hiba történt.", e);
      error = e;
    }
    
    if (error == null) {
      System.out.print(" - Sikeres");
      int value = ((GradedTestCase)tc).points;
      if (value != 0) {
        addPoints(value);
        System.out.print(", " + (value > 0 ? "+" : "-") + Math.abs(value) + " pont ; Eddig " + getPoints() + " pont.");
      }
      System.out.println();
    } else {
      System.out.println(" - Sikertelen");
      
      throw error;
    }
  }
  
  @Override
  protected void after() {
    this.makeFinalGrade();
  }
  
  public void addGradeBorder(int pointCount) {
    gradeBorders.add(new Integer(pointCount));
  }
  
  public void addPoints(int amount) {
    currentPoints += amount;
  }
  
  public int getPoints() {
    return currentPoints;
  }
  
  private int getGrade() {
    int grade = 0;
    for (Integer i : gradeBorders)
      if (getPoints() >= i)
        ++grade;
      else
        break;
    
    return grade;
  }
  
  private void makeFinalGrade() {
    System.out.println("Elért pontok: " + getPoints() + "\t\t\tÉrdemjegy: " + getGrade());
  }
}