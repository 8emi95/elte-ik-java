package hu.elte.inf.pnyf.whisperity.tester;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class Tester {
  /* ** A leszármazott osztályok belső adattagjai ** */
  protected String suiteName = "__UNDEFINED_TEST_SUITE__";
  protected ArrayList<String> dependencySuiteNames = new ArrayList<String>();
  
  /* ** Ezeket a metódusokat kell implementálnia a leszármazott osztályoknak! ** */
  public abstract void setup();
  public abstract void runTests();
  public abstract void teardown();
  
  public String getSuiteName() {
    return suiteName;
  }
  
  public ArrayList<String> getDependencies() {
    return new ArrayList<String>(dependencySuiteNames);
  }
  
  /* --- Reflection accessor helper --- */
  @SuppressWarnings("unchecked")
  public static void checkField(Class clazz, String fieldName, int mFlags, Class type) {
    try {
      Field f = clazz.getDeclaredField(fieldName);
      int fMod = f.getModifiers();
      
      if (mFlags == 0)
        assertTrue("'" + fieldName + "' rendelkezik specialis lathatosagi es egyeb modositokkal, pedig nem kene neki.", fMod == 0);
      
      assertTrue("'" + fieldName + "' nem vedett a konstruktoron kivuli ertekadassal szemben.", Modifier.isFinal(mFlags) == Modifier.isFinal(fMod));
      assertTrue("'" + fieldName + "' nem a megfelelo helyen (osztaly vagy peldanyszint) van tarolva.", Modifier.isStatic(mFlags) == Modifier.isStatic(fMod));
      assertTrue("'" + fieldName + "' lathatosaga hibas.", Modifier.isPublic(mFlags) == Modifier.isPublic(fMod));
      assertTrue("'" + fieldName + "' lathatosaga hibas.", Modifier.isProtected(mFlags) == Modifier.isProtected(fMod));
      assertTrue("'" + fieldName + "' lathatosaga hibas.", Modifier.isPrivate(mFlags) == Modifier.isPrivate(fMod));
      
      assertTrue("'" + fieldName + "' tipusa hibas!", f.getType().equals(type));
    } catch (NoSuchFieldException ex) {
      giveError("Nem talalhato adattag '" + fieldName + "'!");
    }
  }
  
  @SuppressWarnings("unchecked")
  public static void checkMethod(Class clazz, String methodName, int mFlags, Class returnType, Class<?>... argTypes) {
    try {
      Method m = clazz.getDeclaredMethod(methodName, argTypes);
      int mMod = m.getModifiers();
      
      if (mFlags == 0)
        assertTrue("'" + methodName + "' rendelkezik specialis lathatosagi es egyeb modositokkal, pedig nem kene neki.", mMod == 0);
      
      assertTrue("'" + methodName + "' nem varja el a feluldefinialast.", Modifier.isAbstract(mFlags) == Modifier.isAbstract(mMod));
      assertTrue("'" + methodName + "' nem vedett a feluldefinialassal szemben.", Modifier.isFinal(mFlags) == Modifier.isFinal(mMod));
      assertTrue("'" + methodName + "' nem a megfelelo helyen (osztaly vagy peldanyszint) van tarolva.", Modifier.isStatic(mFlags) == Modifier.isStatic(mMod));
      assertTrue("'" + methodName + "' lathatosaga hibas.", Modifier.isPublic(mFlags) == Modifier.isPublic(mMod));
      assertTrue("'" + methodName + "' lathatosaga hibas.", Modifier.isProtected(mFlags) == Modifier.isProtected(mMod));
      assertTrue("'" + methodName + "' lathatosaga hibas.", Modifier.isPrivate(mFlags) == Modifier.isPrivate(mMod));
      
      assertTrue("'" + methodName + "' tipusa hibas!", m.getReturnType().equals(returnType));
    } catch (NoSuchMethodException ex) {
      giveError("Nem talalhato eljaras '" + methodName + "'!");
    }
  }
  
  @SuppressWarnings("unchecked")
  public static final HashMap<String, Object> fullAccess(Object p, ArrayList<String> fieldNames) {
    return fullAccess(p, p.getClass(), fieldNames);
  }
  
  @SuppressWarnings("unchecked")
  public static final HashMap<String, Object> fullAccess(Object p, Class pType, ArrayList<String> fieldNames) {
    HashMap<String, Object> retVal = new HashMap<String, Object>(fieldNames.size());
    
    if (p == null || fieldNames.size() == 0)
      return retVal;
    
    for (String fieldName : fieldNames) {
      try {
          Field f = pType.getDeclaredField(fieldName);
          f.setAccessible(true);
          retVal.put(fieldName, f.get(p));
      } catch (NoSuchFieldException ex) {
          throw new RuntimeException("TESZTELO HIBA! (NSFE) Nem sikerult '" + fieldName + "' adattagot kivulrol elerni.");
      } catch (IllegalAccessException ex) {
          throw new RuntimeException("TESZTELO HIBA! (IAE) Nem sikerult '" + fieldName + "' adattagot kivulrol elerni.");
      }
    }
    
    return retVal;
  }
  
  /* --- Helper methods to easily throw errors --- */
  public static void giveError(String msg) {
    throw new TestCaseException("\n\t" + msg + "\n");
  }

  public static void assertFalse(String msg, boolean p) {
    if (p)
      giveError(msg);
  }

  public static void assertTrue(String msg, boolean p) {
    if (!p)
      giveError(msg);
  }

  public static void assertEquals(String msg, Object expected, Object actual) {
    if (expected == null && actual == null)
      return;

    if (expected == null || !expected.equals(actual))
      throw new TestCaseException("\n\t" + msg + "\n\t\telvárt válasz: " + expected
              + "\n\t\tkapott válasz: " + actual + "\n");
  }

  public static void assertNotEquals(String msg, Object expected, Object actual) {
    if (expected == null && actual == null)
      return;

    if (expected == null || expected.equals(actual))
      throw new TestCaseException("\n\t" + msg + "\n\t\telvárt válasz: " + expected
              + "\n\t\tkapott válasz: " + actual + "\n");
  }
}