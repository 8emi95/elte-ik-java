package hu.elte.inf.pnyf.whisperity.tester;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringJoiner;

public abstract class TestEnvironment {
  public void run() {
    if (Suites.size() == 0) {
      System.out.println("HIBA! Nem valódi tesztegység került elindításra.");
      System.out.println("A tesztkörnyezet önmagában NEM futtatható! Kérlek, egy tesztfájlt indíts el!");
      System.exit(69);
    }
    
    this.before();
    
    int _Done_Test_Count = 0;
    
    {
      StringJoiner sjLoad = new StringJoiner(", ");
      StringJoiner sjSkip = new StringJoiner(", ");
      int loadedCount = 0;
      int skippedCount = 0;
      
      for (TestRun tr : Suites) {
        if (tr.status == Status.SKIPPED) {
          ++skippedCount;
          sjSkip.add(tr.testerObject.suiteName);
        }
        else if (tr.status == Status.UNASSIGNED) {
          ++loadedCount;
          sjLoad.add(tr.testerObject.suiteName);
        }
      }
      
      System.out.print(loadedCount + " tesztegység betöltve: ");
      System.out.println(sjLoad.toString() + ".");
      
      if (skippedCount > 0) {
        System.out.print(skippedCount + " tesztegység betöltése MEGHIUSULT: ");
        System.out.println(sjSkip.toString() + ".");
      }
      System.out.print("\n----------------------------\n\n");
    }
    
    // Ha legalább egy tesztegység regisztrálásra került, beindítjuk a tesztelőt
    int iterationCount = 2 * Suites.size();
    while (true) {
      --iterationCount;
      
      if (iterationCount < 0) {
        System.out.println("\n\nKRITIKUS HIBA! Végtelenciklus-védelem aktiválásra került.");
        System.out.println("A tesztesetek futtatása során a tesztkörnyezet Theta(2n) lépés alatt sem jutott megállási konfigurációba.");
        System.out.println("Ennek leggyakoribb oka egy irányított kör a függőségi gráfban, vagy egy súlyos üzleti logikai hiba a végrehajtó modulokban.");
        break;
      }
      
      _Done_Test_Count = 0;
      // Kiszámoljuk mennyi "végzett" tesztegység van
      for (TestRun tr : Suites) {
        if (tr.status == Status.FINISHED || tr.status == Status.FAILED || tr.status == Status.SKIPPED)
          ++_Done_Test_Count;
        else if (tr.status != Status.RUNNING) {
          System.out.println("\n>> " + tr.testerObject.suiteName + " tesztelése...");
          
          try {
            tr.dispatch();
          } catch (Exception e) {
            System.out.println("\n\nA tesztegység futtatása közben nem várt hiba lépett fel:");
            
            e.printStackTrace();
            System.out.println("\n\tA végösszeomlás-védelem aktiválásra került.");
            System.out.println("\n\t!!FIGYELEM!!");
            System.out.println("\t\tEz a hiba NEM a tesztelő kód által került direkt módon kiváltásra, hanem egy, a végrehajtott feladatmegoldásban\n\t\tkiváltott kivétel próbált lekezeletlenül eljutni a main() metódus aktivációs rekordjáig.");
            
            tr.status = Status.SKIPPED;
          }
          
          if (tr.status == Status.FINISHED)
            System.out.println("Tesztegység futtatása SIKERES.");
          else if (tr.status == Status.WAIT_DEPENDENCIES) {
            System.out.print("\tNem lehetséges, a tesztegység más, még nem lefutott tesztegységektől függ: ");
            DependencyResultSet drs = checkDependenciesFor(tr);
            StringJoiner sj2 = new StringJoiner(", ");
            for (TestRun dep : drs.rest) {
              sj2.add(dep.testerObject.suiteName);
            }
            System.out.println(sj2.toString());
          }
          else {
            if (tr.status == Status.SKIPPED)
              System.out.println("Tesztegység futtatása KIHAGYVA.");
            if (tr.status == Status.FAILED)
              System.out.println("Tesztegység futtatása SIKERTELEN.");
            
            if (tr.failureReason instanceof IllegalStateException) {
              // Az IllegalStateException egy speciális kivétel, amely azt jelzi, hogy a tesztegység függőségi hiba miatt nem futtatható.
              // Ekkor nem kell egy teljes stack trace-t kiírni.
              System.out.println("\nIndoklás: ");
              System.out.println(tr.failureReason.getMessage());
            } else if (tr.failureReason != null) {
              // Minden más hibánál jelenítsük meg a megfelelő hibát.
              System.out.println("\n\nA hiba okaként a következő kivételt jelölték meg: ");
              tr.failureReason.printStackTrace();
            }
          }
        }
      }
      
      if (_Done_Test_Count == Suites.size())
        break;
    }
    
    int skipped = 0, success = 0, failure = 0;
    for (TestRun tr : Suites)
      if (tr.status == Status.FINISHED)
          ++success;
      else if (tr.status == Status.SKIPPED) 
          ++skipped;
      else if (tr.status == Status.FAILED)
          ++failure;
    
    System.out.print("\n----------------------------\n");
    if (success == Suites.size()) {
      System.out.println(success + " sikeres.");
      System.out.println("\nSiker! Minden - kívant - tesztegység lefutott!");
    } else {
      StringJoiner sj2 = new StringJoiner("\n");
      if (success > 0)
        sj2.add(success + " sikeres.");
      if (failure > 0)
        sj2.add(failure + " sikertelen.");
      if (skipped > 0)
        sj2.add(skipped + " kihagyva.");
      
      System.out.println(sj2.toString() + "\n\nA tesztek futtatása során hiba történt!\n" +
            "A hibát megelözö jó megoldások alapján az eredményed eddig:");
    }
    
    this.after();
    
    // Swiggity swooty... így tutira nem fog átmenni a teszteken, de ha meg megbukik, a return érték kicsit dinamikus lesz :P
    if (success == Suites.size())
      System.exit(0);
    else
      System.exit( (failure+skipped == 0 ? 1 : failure+skipped) );
  }
  
  protected abstract void before();
  public abstract void runTestCase(TestCase tc);
  protected abstract void after();
  
  /* --- Global space --- */
  private HashMap<String, Object> _GLOBALS = new HashMap<String, Object>();
  
  @SuppressWarnings("unchecked")
  public <T> T getGlobal(String name) {
    Object val = _GLOBALS.get(name);
    
    T retval;
    try {
      retval = (T)val;
    } catch (ClassCastException ex) {
      return null;
    }
    
    return retval;
  }
  
  public void setGlobal(String name, Object o) {
    _GLOBALS.put(name, o);
  }
  
  /* --- Dependency and test suite handler --- */
  private ArrayList<TestRun> Suites = new ArrayList<TestRun>();
  
  protected TestRun getTestRunBySuiteName(String name) {
    for (TestRun tr : Suites)
      if (tr.testerObject.suiteName.equals(name))
        return tr;
    
    return null;
  }
  
  public void loadTestSuite(String className, String suiteName) {
    Throwable error = null;
    
    try {
      Class<?> clazz = Class.forName(className);
      Constructor<?> con = clazz.getDeclaredConstructor();
      con.setAccessible(true);
      con.newInstance();
    } catch (ClassNotFoundException cnfe) {
      error = cnfe;
    } catch (InstantiationException ie) {
      error = ie;
    } catch (IllegalAccessException iae) {
      error = iae;
    } catch (NoSuchMethodException nsme) {
      error = nsme;
    } catch (java.lang.reflect.InvocationTargetException ite) {
      error = ite;
    }
    
    if (error != null) {
      error = new IllegalStateException("Egy függő osztályt nem sikerült betölteni, így a tesztegység nem tölthető be. Valószínűleg az implementáció még nem készült el.", error);
      
      Tester t = new Tester(){
        @Override public void setup(){}
        @Override public void runTests(){}
        @Override public void teardown(){}
      };
      t.suiteName = suiteName;
      
      TestRun tr = new TestRun(t, this){
        {
          status = Status.SKIPPED;
        }
        
        // My god this is such a f'ing hack, but yeah this works...
        TestRun setFailReason(Throwable t) { failureReason = t; return this; }
        @Override public void dispatch() {}
      }.setFailReason(error);
      
      // Automatically register an auto-skipped tester if the lazy loading fails.
      Suites.add(tr);
    }
  }
  
  public void registerSuite(Tester suite) {
    if (getTestRunBySuiteName(suite.suiteName) != null)
      //throw new InvalidArgumentException("The '" + suite.suiteName + "' test suite was already registered.");
      return;
    
    Suites.add(new TestRun(suite, this));
  }
  
  public void createOrLoadDependency(Tester suite, Tester dependency) {
    if (getTestRunBySuiteName(dependency.suiteName) == null) {
      registerSuite(dependency);
    }
    
    suite.dependencySuiteNames.add(dependency.suiteName);
  }
  
  protected class DependencyResultSet {
    ArrayList<TestRun> successful = new ArrayList<TestRun>();
    ArrayList<TestRun> failed = new ArrayList<TestRun>();
    ArrayList<TestRun> skipped = new ArrayList<TestRun>();
    ArrayList<TestRun> rest = new ArrayList<TestRun>();
    
    boolean greenlight = false;
  }
  
  protected DependencyResultSet checkDependenciesFor(TestRun testRun) {
    DependencyResultSet drs = new DependencyResultSet();
    
    for (String dependencyName : testRun.testerObject.dependencySuiteNames) {
      TestRun dependency = getTestRunBySuiteName(dependencyName);
      
      switch (dependency.status) {
        case FINISHED:
          drs.successful.add(dependency);
          break;
        case FAILED:
          drs.failed.add(dependency);
          break;
        case SKIPPED:
          drs.skipped.add(dependency);
          break;
        default:
          drs.rest.add(dependency);
          break;
      }
    }
    
    if (drs.successful.size() == testRun.testerObject.dependencySuiteNames.size() && drs.failed.size() == 0 && drs.skipped.size() == 0 && drs.rest.size() == 0) {
      drs.greenlight = true;
    }
    
    return drs;
  }
}

