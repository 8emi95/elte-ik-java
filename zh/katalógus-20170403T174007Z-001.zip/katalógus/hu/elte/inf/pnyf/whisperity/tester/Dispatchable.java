package hu.elte.inf.pnyf.whisperity.tester;

@FunctionalInterface
public interface Dispatchable {
  void dispatch();
}