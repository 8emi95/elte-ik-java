package hu.elte.inf.pnyf.whisperity.tester;

public class TestCaseException extends RuntimeException {
  public TestCaseException() {}
  
  public TestCaseException(String message) {
    super(message);
  }
  
  public TestCaseException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public TestCaseException(Throwable cause) {
    super(cause);
  }
}