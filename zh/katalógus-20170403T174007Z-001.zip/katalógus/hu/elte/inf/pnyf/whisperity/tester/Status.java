package hu.elte.inf.pnyf.whisperity.tester;

public enum Status {
  UNASSIGNED,               // Not started yet
  SKIPPED,                  // Was skipped due to an internal or external error, but not because of a failing test case
  WAIT_DEPENDENCIES,        // Cannot run yet because dependencies are unmatched
  RUNNING,                  // Is currently running
  FINISHED,                 // Successfully ran
  FAILED;                   // Failed on a test case
}