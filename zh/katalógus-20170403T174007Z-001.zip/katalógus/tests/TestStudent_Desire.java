package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import university.entities.Student;
import university.events.Attendable;
import university.events.FacultyDay;

public class TestStudent_Desire extends Tester {
  private Student s1, s2, s3;
  
  private class _A implements Attendable {
    public int getLean() { return 100; }
    public boolean isAttendanceMandatory() { return true; }
  }
  
  private class _B implements Attendable {
    public int getLean() { return 0; }
    public boolean isAttendanceMandatory() { return true; }
  }
  
  private class _C implements Attendable {
    public int getLean() { return 50; }
    public boolean isAttendanceMandatory() { return false; }
  }
  
  private class _D implements Attendable {
    public int getLean() { return 75; }
    public boolean isAttendanceMandatory() { return true; }
  }
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY", 100, 0);
    s2 = new Student("Gipsz Jakab", "BATMAN", 50, 50);
    s3 = new Student("Mikecz Márk", "LOCU01", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("hasAttendanceDesire", () -> hasAttendanceDesire(), 3));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    checkMethod(Student.class, "hasAttendanceDesire", Modifier.PUBLIC, boolean.class, Attendable.class);
    checkMethod(Student.class, "hasAttendanceDesire", Modifier.PUBLIC, boolean.class, FacultyDay.class);
  }
  
  private void hasAttendanceDesire() {
    assertTrue("A hasAttendanceDesire rossz választ adott.", s1.hasAttendanceDesire(new _A())); // (100 + 100) * (100 - 0) / 100 = 200 >= 50: T
    assertTrue("A hasAttendanceDesire rossz választ adott.", s1.hasAttendanceDesire(new _B())); // (100 + 0) * (100 - 0) / 100 = 100 >= 50: T
    assertTrue("A hasAttendanceDesire rossz választ adott.", s1.hasAttendanceDesire(new _C())); // (100 + 50) * (100 - 0) / 100 / 2 = 75 >= 50: T
    assertTrue("A hasAttendanceDesire rossz választ adott.", s1.hasAttendanceDesire(new _D())); // (100 + 75) * (100 - 0) / 100 = 175 >= 50: T
    
    assertTrue("A hasAttendanceDesire rossz választ adott.", s2.hasAttendanceDesire(new _A()));  // (50 + 100) * (100 - 50) / 100 = 75 >= 50: T
    assertFalse("A hasAttendanceDesire rossz választ adott.", s2.hasAttendanceDesire(new _B()));  // (50 + 0) * (100 - 50) / 100 = 25 >= 50: F
    assertFalse("A hasAttendanceDesire rossz választ adott.", s2.hasAttendanceDesire(new _C()));  // (50 + 50) * (100 - 50) / 100 / 2 = 25 >= 50: F
    assertTrue("A hasAttendanceDesire rossz választ adott.", s2.hasAttendanceDesire(new _D()));  // (50 + 75) * (100 - 50) / 100 = 62.5 >= 50: T
    
    assertFalse("A hasAttendanceDesire rossz választ adott.", s3.hasAttendanceDesire(new _A())); // (0 + 100) * (100 - 100) / 100 = 0 >= 50: F
    assertFalse("A hasAttendanceDesire rossz választ adott.", s3.hasAttendanceDesire(new _B())); // (0 + 0) * (100 - 100) / 100 = 0 >= 50: F
    assertFalse("A hasAttendanceDesire rossz választ adott.", s3.hasAttendanceDesire(new _C())); // (0 + 50) * (100 - 100) / 100 / 2 = 0 >= 50: F
    assertFalse("A hasAttendanceDesire rossz választ adott.", s3.hasAttendanceDesire(new _D())); // (0 + 75) * (100 - 100) / 100 = 0 >= 50: F
    
    assertTrue("A hasAttendanceDesire rossz választ adott.", s1.hasAttendanceDesire(new FacultyDay()));
    assertFalse("A hasAttendanceDesire rossz választ adott.", s2.hasAttendanceDesire(new FacultyDay()));
    assertFalse("A hasAttendanceDesire rossz választ adott.", s3.hasAttendanceDesire(new FacultyDay()));
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestStudent_Desire() {
    this.suiteName = "Student/hasAttendanceDesire";
    
    Test._Environment.createOrLoadDependency(this, new TestStudent());  
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    Test._Environment.createOrLoadDependency(this, new TestFacultyDay());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestStudent_Desire();
    Test.main(args);
  }
}
