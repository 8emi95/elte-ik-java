package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;

import university.entities.Student;
import university.events.Attendable;
import university.events.Consultation;

public class TestConsultation extends Tester {
  private Student s1, s2;
  private Consultation con1, con2;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok, getterek", () -> _CtorAndGetter(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Object-ből örökölt három metódus", () -> _EqualitySet(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void _CtorAndGetter() {
    Constructor();
    Getters();
  }
  
  private void _EqualitySet() {
    equals_();
    hashCode_();
    toString_();
  }
  
  private void Reflection() {
    assertTrue("A Consultation osztály nem implementálja az Attendable interfészt.", Attendable.class.isAssignableFrom(Consultation.class));
    
    checkMethod(Consultation.class, "getLean", Modifier.PUBLIC, int.class);
    checkMethod(Consultation.class, "isAttendanceMandatory", Modifier.PUBLIC, boolean.class);
    checkMethod(Consultation.class, "equals", Modifier.PUBLIC, boolean.class, Object.class);
    checkMethod(Consultation.class, "hashCode", Modifier.PUBLIC, int.class);
    checkMethod(Consultation.class, "toString", Modifier.PUBLIC, String.class);
  }
  
  private void Constructor() {
    con1 = new Consultation("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "IP-08cPNY2EG", con1.getCourseCode());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Programozási nyelvek II. - JAVA", con1.getName());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Kozsik Tamás", con1.getProfessor());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, con1.getStudents().size());
    
    con2 = new Consultation("Foo", "Bar Baz", "Qux");
  }
  
  private void Getters() {
    assertEquals("A getLean metódus hibás választ adott.", 15, con1.getLean());
    assertEquals("A isAttendanceMandatory metódus hibás választ adott.", false, con1.isAttendanceMandatory());
  }
  
  private void equals_() {
    assertFalse("Az equals egyenlőnek talált két eltérő tárgykódú konzultációt.", con1.equals(con2));
    Consultation con3 = new Consultation("IP-08cPNY2EG", "Jáva EA", "Jáva Tanszék");
    assertTrue("Az equals nem talált egyenlőnek talált két azonos tárgykódú konzultációt.", con1.equals(con3));
    
    assertFalse("Az equals rossz választ ad eltérő típusok esetén.", con1.equals(new String("IP-08cPNY2EG")));
  }
  
  private void hashCode_() {
    assertEquals("A hashCode hibás választ adott.", new String("IP-08cPNY2EG").hashCode() * 1000, con1.hashCode());
    assertEquals("A hashCode hibás választ adott.", new String("Foo").hashCode() * 1000, con2.hashCode());
  }
  
  private void toString_() {
    con1.addStudent(s1);
    con1.addStudent(s2);
    
    assertEquals("A toString hibás Stringet adott vissza.", "(2)Programozási nyelvek II. - JAVA[IP-08cPNY2EG](Kozsik Tamás){Konzultáció}", con1.toString());
    
    assertEquals("A toString hibás Stringet adott vissza.", "(0)Bar Baz[Foo](Qux){Konzultáció}", con2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestConsultation() {
    this.suiteName = "Consultation";
    
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    Test._Environment.createOrLoadDependency(this, new TestCourse());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestConsultation();
    Test.main(args);
  }
}
