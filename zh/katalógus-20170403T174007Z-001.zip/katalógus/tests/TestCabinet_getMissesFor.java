package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import university.Cabinet;
import university.Roster;
import university.entities.Student;
import university.events.Attendable;
import university.events.Consultation;
import university.events.Course;
import university.events.Lecture;
import university.events.OfficeHour;
import university.events.Practice;

public class TestCabinet_getMissesFor extends Tester {
  private Student s1, s2, s3, s4, s5;
  private Lecture lec1, lec4;
  private Practice pra1, pra4;
  private Consultation con1, con4;
  private OfficeHour oh1, oh4;
  
  private Cabinet cabinet;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
    s3 = new Student("Mikecz Márk", "LOCU01", 0, 0);
    s4 = new Student("Eötvös Loránd", "ELTEHU", 100, 0);
    s5 = new Student("Alexstrasza", "DTHWNG", new java.util.Random().nextInt(100), new java.util.Random().nextInt(100));
    
    lec1 = new Lecture("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    pra1 = new Practice("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    con1 = new Consultation("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    oh1 = new OfficeHour("Kozsik Tamás");
    
    lec4 = new Lecture("IP-08cAN1E", "Analízis 1.", "Szili László");
    pra4 = new Practice("IP-08cAN1G", "Analízis 1.", "Szili László");
    con4 = new Consultation("IP-08cAN1E", "Analízis 1.", "Szili László");
    oh4 = new OfficeHour("Szili László");
  }
  
  @Override
  public void runTests() {
    Test._Environment.runTestCase(new GradedTestCase("getMissesFor", () -> getMissesFor(), 6));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void getMissesFor() {
    cabinet = new Cabinet();
    
    assertEquals("A hallgatók kezdetben tévesen rendelkeznek hiányzási pontokkal.", 0, cabinet.getMissesFor(s1));
    assertEquals("A hallgatók kezdetben tévesen rendelkeznek hiányzási pontokkal.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hallgatók kezdetben tévesen rendelkeznek hiányzási pontokkal.", 0, cabinet.getMissesFor(s3));
    assertEquals("A hallgatók kezdetben tévesen rendelkeznek hiányzási pontokkal.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hallgatók kezdetben tévesen rendelkeznek hiányzási pontokkal.", 0, cabinet.getMissesFor(s5));
    
    // Adjunk hozzá egy tárgyat és néhány hallgatót...
    Roster<Lecture> javaEA = new Roster<Lecture>(lec1, 0, 5);
    lec1.addStudent(s1);
    lec1.addStudent(s5);
    
    // S1 és S5 most egy hiányzási ponttal kell rendelkezzen, mert nem írták alá a katalógust.
    cabinet.addRoster(javaEA);
    
    assertEquals("A hiányzási pontok számítása rossz eredményt adott hiányzások esetén.", 1, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott hiányzások esetén.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott hiányzások esetén.", 0, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott hiányzások esetén.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott hiányzások esetén.", 1, cabinet.getMissesFor(s5));
    
    // S1 aláírta -> neki már nincs hiányzási pontja
    javaEA.attend(s1);
    assertEquals("A hiányzási pontok számítása rossz eredményt adott, amikor két emberből egy aláírta a katalógust.", 0, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott, amikor két emberből egy aláírta a katalógust.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott, amikor két emberből egy aláírta a katalógust.", 0, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott, amikor két emberből egy aláírta a katalógust.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számítása rossz eredményt adott, amikor két emberből egy aláírta a katalógust.", 1, cabinet.getMissesFor(s5));
    
    // Vigyünk fel egy konzultációt is.
    Roster<Consultation> javaKonzi = new Roster<Consultation>(con1, 0, 5);
    con1.addStudent(s5);
    cabinet.addRoster(javaKonzi);
    
    // Ettől még alapvetően semmi nem változik, mivel konzultációra járni nem kötelező
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy látogatás nélküli konzultáció beszámításakor.", 0, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy látogatás nélküli konzultáció beszámításakor.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy látogatás nélküli konzultáció beszámításakor.", 0, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy látogatás nélküli konzultáció beszámításakor.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy látogatás nélküli konzultáció beszámításakor.", 1, cabinet.getMissesFor(s5));
    
    // De ha bemegy, 0,5 pontot elveszít... 1 - 0.5 lefelé kerekítve 0.
    javaKonzi.attend(s5);
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy konzultáció beszámításakor.", 0, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy konzultáció beszámításakor.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy konzultáció beszámításakor.", 0, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy konzultáció beszámításakor.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számítása rossz eredmény adott egy konzultáció beszámításakor.", 0, cabinet.getMissesFor(s5));
    
    // Tornásszuk fel kicsit a hiányzásokat
    lec4.addStudent(s1);
    lec4.addStudent(s3);
    lec4.addStudent(s5);
    Roster<Lecture> analEA1 = new Roster<Lecture>(lec4, 0, 5);
    Roster<Lecture> analEA2 = new Roster<Lecture>(lec4, 1, 5);
    Roster<Lecture> analEA3 = new Roster<Lecture>(lec4, 2, 5);
    Roster<Lecture> analEA4 = new Roster<Lecture>(lec4, 2, 5);
    Roster<Lecture> analEA5 = new Roster<Lecture>(lec4, 2, 5);
    
    cabinet.addRoster(analEA1);
    cabinet.addRoster(analEA2);
    cabinet.addRoster(analEA3);
    cabinet.addRoster(analEA4);
    cabinet.addRoster(analEA5);
    
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 5, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 5, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 5, cabinet.getMissesFor(s5));
    
    // S5-nek itt 2x0.5 pontot levonunk, bent volt konzultáción.
    Roster<Consultation> analKonzi = new Roster<Consultation>(con4, 0, 5);
    Roster<Consultation> analKonzi2 = new Roster<Consultation>(con4, 0, 5);
    con4.addStudent(s5);
    analKonzi.attend(s5);
    analKonzi2.attend(s5);
    cabinet.addRoster(analKonzi);
    cabinet.addRoster(analKonzi2);
    
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 5, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 5, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számításakor rosszul kezelünk több tárgyat.", 4, cabinet.getMissesFor(s5));
    
    // Mindenkit résztvetetünk 10 fogadóórán a két tanárnál.
    // Ennek hatására S1 és S5 hiányzási pontja 10*0.1 = 1-gyel csökken (többieké nem, hiszen nem vették fel a Java-t)
    // De S1, S3 és S5 hiányzási pontja még 1-gyel csökken, mivel mindhárman felvették az analízist és 10x bent voltak a konzultáción.
    for (int i = 0; i < 10; ++i) {
      Roster<OfficeHour> kozsik = new Roster<OfficeHour>(oh1, 0, 5);
      Roster<OfficeHour> szili = new Roster<OfficeHour>(oh4, 0, 5);
      kozsik.attend(s1);
      kozsik.attend(s2);
      kozsik.attend(s3);
      kozsik.attend(s4);
      kozsik.attend(s5);
      
      szili.attend(s1);
      szili.attend(s2);
      szili.attend(s3);
      szili.attend(s4);
      szili.attend(s5);
      
      cabinet.addRoster(kozsik);
      cabinet.addRoster(szili);
    }
    
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a fogadóórán részvételt.", 3, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a fogadóórán részvételt.", 0, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a fogadóórán részvételt.", 4, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a fogadóórán részvételt.", 0, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a fogadóórán részvételt.", 2, cabinet.getMissesFor(s5));
    
    // Na dobjunk be még néhány bónusz pontot: S2 és S4 20-at, S5 10-et kap.
    for (int i = 0; i < 20; ++i) {
      cabinet.registerBonus(s2);
      cabinet.registerBonus(s4);
      if (i % 2 == 1) {
        cabinet.registerBonus(s5);
      }
    }
    
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a bónuszpontokat.", 3, cabinet.getMissesFor(s1));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a bónuszpontokat.", -2, cabinet.getMissesFor(s2));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a bónuszpontokat.", 4, cabinet.getMissesFor(s3));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a bónuszpontokat.", -2, cabinet.getMissesFor(s4));
    assertEquals("A hiányzási pontok számításakor nem jól számítottuk be a bónuszpontokat.", 1, cabinet.getMissesFor(s5));
    
    // Extrém esetek kezelése -> biztos jól védekezik a hallgató a bejárásra alkalmas tulajdonság mentén?
    try {
      _C nonAttendableCourse = new _C("IP-08SZDLG", "Szakdolgozat konzultáció", "Burcsi Péter");
      OfficeHour burcsi = new OfficeHour("Burcsi Péter");
      
      Roster<_C> konzi1 = new Roster<_C>(nonAttendableCourse, 0, 5);
      Roster<_C> konzi2 = new Roster<_C>(nonAttendableCourse, 1, 5);
      Roster<OfficeHour> burcsi1 = new Roster<OfficeHour>(burcsi, 0, 5);
      Roster<OfficeHour> burcsi2 = new Roster<OfficeHour>(burcsi, 1, 5);
      
      nonAttendableCourse.addStudent(s3);
      konzi1.attend(s3);
      konzi1.attend(s5);
      konzi2.attend(s3);
      burcsi1.attend(s3);
      burcsi2.attend(s3);
      
      cabinet.addRoster(konzi1);
      cabinet.addRoster(konzi2);
      cabinet.addRoster(burcsi1);
      cabinet.addRoster(burcsi2);
      
      assertEquals("A hiányzási pontoknál figyelembe vettünk nem \"bejárásra alkalmas\" eseményekhez tartozó jelenléti íveket is.", 3, cabinet.getMissesFor(s1));
      assertEquals("A hiányzási pontoknál figyelembe vettünk nem \"bejárásra alkalmas\" eseményekhez tartozó jelenléti íveket is.", -2, cabinet.getMissesFor(s2));
      assertEquals("A hiányzási pontoknál figyelembe vettünk nem \"bejárásra alkalmas\" eseményekhez tartozó jelenléti íveket is.", 4, cabinet.getMissesFor(s3));
      assertEquals("A hiányzási pontoknál figyelembe vettünk nem \"bejárásra alkalmas\" eseményekhez tartozó jelenléti íveket is.", -2, cabinet.getMissesFor(s4));
      assertEquals("A hiányzási pontoknál figyelembe vettünk nem \"bejárásra alkalmas\" eseményekhez tartozó jelenléti íveket is.", 1, cabinet.getMissesFor(s5));
    } catch (ClassCastException cce) {
      // Noop. This exception should happen.
    }
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  private class _C extends Course {
    public _C(String a, String b, String c) { super(a, b, c); }
    public boolean equals(Object a) { return false; }
    public int hashCode() { return 0; }
  }
  
  TestCabinet_getMissesFor() {
    this.suiteName = "Cabinet/getMissesFor";
    
    Test._Environment.createOrLoadDependency(this, new TestCabinet());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestCabinet_getMissesFor();
    Test.main(args);
  }
}
