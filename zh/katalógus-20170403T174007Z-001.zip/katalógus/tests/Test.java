package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

public class Test {
  public static GradingTestEnvironment _Environment;
  
  public static void createEnv() {
    _Environment = new GradingTestEnvironment(0); // Kezdeti pontszám
    _Environment.addGradeBorder(0); // Minimum
    _Environment.addGradeBorder(33); // Kettes
    _Environment.addGradeBorder(53); // Harmas
    _Environment.addGradeBorder(65); // Negyes
    _Environment.addGradeBorder(77); // Otos
    _Environment.addGradeBorder(90); // Maximum
  }
  
  public static void main(String[] args) {
    if (_Environment == null) {
      createEnv();
            
      _Environment.loadTestSuite("tests.TestStudent", "Student");
      _Environment.loadTestSuite("tests.TestAttendable", "Attendable");
      _Environment.loadTestSuite("tests.TestCourse", "Course");
      _Environment.loadTestSuite("tests.TestLecture", "Lecture");
      _Environment.loadTestSuite("tests.TestPractice", "Practice");
      _Environment.loadTestSuite("tests.TestConsultation", "Consultation");
      _Environment.loadTestSuite("tests.TestCourse_EqualityXTypes", "Course/equality-across-types");
      _Environment.loadTestSuite("tests.TestOfficeHour", "OfficeHour");
      _Environment.loadTestSuite("tests.TestFacultyDay", "FacultyDay");
      _Environment.loadTestSuite("tests.TestRoster", "Roster");
      // _Environment.loadTestSuite("tests.TestCabinet", "Cabinet");
      // _Environment.loadTestSuite("tests.TestCabinet_getMissesFor", "Cabinet/getMissesFor");
      // _Environment.loadTestSuite("tests.TestStudent_Desire", "Student/hasAttendanceDesire");
      // _Environment.loadTestSuite("tests.TestSemesterSimulation_Prepare", "SemesterSimulation/Prepare");
      // _Environment.loadTestSuite("tests.TestSemesterSimulation_Process", "SemesterSimulation/Process");
    }
    
    _Environment.run();
  }
}
