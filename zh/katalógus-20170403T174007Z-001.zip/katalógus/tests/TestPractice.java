package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;

import university.entities.Student;
import university.events.Attendable;
import university.events.Practice;

public class TestPractice extends Tester {
  private Student s1, s2;
  private Practice p1, p2;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok, getterek", () -> _CtorAndGetter(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Object-ből örökölt három metódus", () -> _EqualitySet(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void _CtorAndGetter() {
    Constructor();
    Getters();
  }
  
  private void _EqualitySet() {
    equals_();
    hashCode_();
    toString_();
  }
  
  private void Reflection() {
    assertTrue("A Practice osztály nem implementálja az Attendable interfészt.", Attendable.class.isAssignableFrom(Practice.class));
    
    checkMethod(Practice.class, "getLean", Modifier.PUBLIC, int.class);
    checkMethod(Practice.class, "isAttendanceMandatory", Modifier.PUBLIC, boolean.class);
    checkMethod(Practice.class, "equals", Modifier.PUBLIC, boolean.class, Object.class);
    checkMethod(Practice.class, "hashCode", Modifier.PUBLIC, int.class);
    checkMethod(Practice.class, "toString", Modifier.PUBLIC, String.class);
  }
  
  private void Constructor() {
    p1 = new Practice("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "IP-08cPNY2EG", p1.getCourseCode());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Programozási nyelvek II. - JAVA", p1.getName());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Kozsik Tamás", p1.getProfessor());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, p1.getStudents().size());
    
    p2 = new Practice("Foo", "Bar Baz", "Qux");
  }
  
  private void Getters() {
    assertEquals("A getLean metódus hibás választ adott.", 90, p1.getLean());
    assertEquals("A isAttendanceMandatory metódus hibás választ adott.", true, p1.isAttendanceMandatory());
  }
  
  private void equals_() {
    assertFalse("Az equals egyenlőnek talált két eltérő tárgykódú gyakorlatot.", p1.equals(p2));
    Practice p3 = new Practice("IP-08cPNY2EG", "Jáva EA", "Jáva Tanszék");
    assertTrue("Az equals nem talált egyenlőnek talált két azonos tárgykódú gyakorlatot.", p1.equals(p3));
    
    assertFalse("Az equals rossz választ ad eltérő típusok esetén.", p1.equals(new String("IP-08cPNY2EG")));
  }
  
  private void hashCode_() {
    assertEquals("A hashCode hibás választ adott.", new String("IP-08cPNY2EG").hashCode() * 100, p1.hashCode());
    assertEquals("A hashCode hibás választ adott.", new String("Foo").hashCode() * 100, p2.hashCode());
  }
  
  private void toString_() {
    p1.addStudent(s1);
    p1.addStudent(s2);
    
    assertEquals("A toString hibás Stringet adott vissza.", "(2)Programozási nyelvek II. - JAVA[IP-08cPNY2EG](Kozsik Tamás){Gyakorlat}", p1.toString());
    
    assertEquals("A toString hibás Stringet adott vissza.", "(0)Bar Baz[Foo](Qux){Gyakorlat}", p2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestPractice() {
    this.suiteName = "Practice";
    
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    Test._Environment.createOrLoadDependency(this, new TestCourse());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestPractice();
    Test.main(args);
  }
}
