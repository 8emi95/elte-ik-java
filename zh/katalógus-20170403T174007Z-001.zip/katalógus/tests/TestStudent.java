package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;

import university.entities.Student;

public class TestStudent extends Tester {
  private Student s1, s2, s3;
  
  @Override
  public void runTests() {
    try {
      int pointValue = 2;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok", () -> Constructor(), 2));
    Test._Environment.runTestCase(new GradedTestCase("Getterek", () -> Getters(), 1));
    Test._Environment.runTestCase(new GradedTestCase("toString", () -> toString_(), 1));
    Test._Environment.runTestCase(new GradedTestCase("equals és hashCode", () -> wrap_Equality(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    checkField(Student.class, "name", Modifier.PRIVATE | Modifier.FINAL, String.class);
    checkField(Student.class, "neptun", Modifier.PRIVATE | Modifier.FINAL, String.class);
    checkField(Student.class, "spirit", Modifier.PRIVATE | Modifier.FINAL, int.class);
    checkField(Student.class, "sloth", Modifier.PRIVATE | Modifier.FINAL, int.class);
    
    checkMethod(Student.class, "getName", Modifier.PUBLIC, String.class);
    checkMethod(Student.class, "getNeptun", Modifier.PUBLIC, String.class);
    checkMethod(Student.class, "getSpirit", Modifier.PUBLIC, int.class);
    checkMethod(Student.class, "getSloth", Modifier.PUBLIC, int.class);
  }
  
  private HashMap<String, Object> access(Student s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("name");
    fields.add("neptun");
    fields.add("spirit");
    fields.add("sloth");
    
    return fullAccess(s, fields);
  }
  
  private void Constructor() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Whisperity Dypertkova", "WHISPY", 100, 0);
    s3 = new Student("Locutus", "LOCU01", 0, 0);
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Whisperity Dypertkova", (String)access(s1).get("name"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "WHISPY", (String)access(s1).get("neptun"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 75, (int)access(s1).get("spirit"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 50, (int)access(s1).get("sloth"));
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Whisperity Dypertkova", (String)access(s2).get("name"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "WHISPY", (String)access(s2).get("neptun"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 100, (int)access(s2).get("spirit"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, (int)access(s2).get("sloth"));
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Locutus", (String)access(s3).get("name"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "LOCU01", (String)access(s3).get("neptun"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, (int)access(s3).get("spirit"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, (int)access(s3).get("sloth"));
    
    try {
      new Student("VALAKI", "Nesze!", -50, 10);
      giveError("A konstruktor nem ellenőrizte megfelelően a paraméterek értékeit.");
    } catch (IllegalArgumentException e) {}
    
    try {
      new Student("VALAKI", "Nesze!", 50, -10);
      giveError("A konstruktor nem ellenőrizte megfelelően a paraméterek értékeit.");
    } catch (IllegalArgumentException e) {}
    
    try {
      new Student("VALAKI", "Nesze!", -50, -10);
      giveError("A konstruktor nem ellenőrizte megfelelően a paraméterek értékeit.");
    } catch (IllegalArgumentException e) {}
    
    
    Student copied = s1;
    Student sC = new Student(copied);
    
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (String)access(copied).get("name"), (String)access(sC).get("name"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (String)access(copied).get("neptun"), (String)access(sC).get("neptun"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (int)access(copied).get("spirit"), (int)access(sC).get("spirit"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (int)access(copied).get("sloth"), (int)access(sC).get("sloth"));
    
    copied = s3;
    sC = new Student(copied);
    
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (String)access(copied).get("name"), (String)access(sC).get("name"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (String)access(copied).get("neptun"), (String)access(sC).get("neptun"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (int)access(copied).get("spirit"), (int)access(sC).get("spirit"));
    assertEquals("A másoló konstruktor nem megfelelően inicializálta az adattagokat.", (int)access(copied).get("sloth"), (int)access(sC).get("sloth"));
  }
  
  private void Getters() {
    assertEquals("A getName metódus hibás választ adott.", "Whisperity Dypertkova", s1.getName());
    assertEquals("A getNeptun metódus hibás választ adott.", "WHISPY", s1.getNeptun());
    assertEquals("A getSpirit metódus hibás választ adott.", 75, s1.getSpirit());
    assertEquals("A getSloth metódus hibás választ adott.", 50, s1.getSloth());
    
    assertEquals("A getName metódus hibás választ adott.", "Whisperity Dypertkova", s2.getName());
    assertEquals("A getNeptun metódus hibás választ adott.", "WHISPY", s2.getNeptun());
    assertEquals("A getSpirit metódus hibás választ adott.", 100, s2.getSpirit());
    assertEquals("A getSloth metódus hibás választ adott.", 0, s2.getSloth());
    
    assertEquals("A getName metódus hibás választ adott.", "Locutus", s3.getName());
    assertEquals("A getNeptun metódus hibás választ adott.", "LOCU01", s3.getNeptun());
    assertEquals("A getSpirit metódus hibás választ adott.", 0, s3.getSpirit());
    assertEquals("A getSloth metódus hibás választ adott.", 0, s3.getSloth());
  }
  
  private void toString_() {
    assertEquals("A toString hibás Stringet adott vissza.", "Whisperity Dypertkova{WHISPY}(75|50)", s1.toString());
    assertEquals("A toString hibás Stringet adott vissza.", "Whisperity Dypertkova{WHISPY}(100|0)", s2.toString());
    assertEquals("A toString hibás Stringet adott vissza.", "Locutus{LOCU01}(0|0)", s3.toString());
  }
  
  private void wrap_Equality() {
    equals_();
    hashCode_();
  }
  
  private void equals_() {
    assertTrue("Az equals nem tekint egyenlőnek két hallgatót, akiket kellene.", s1.equals(s2));
    assertTrue("Az equals nem tekint egyenlőnek két hallgatót, akiket kellene.", s2.equals(s1));
    assertFalse("Az equals egyenlőnek két hallgatót, akiket nem szabadna", s1.equals(s3));
    assertFalse("Az equals egyenlőnek két hallgatót, akiket nem szabadna", s2.equals(s3));
    assertFalse("Az equals egyenlőnek két hallgatót, akiket nem szabadna", s3.equals(s1));
    assertFalse("Az equals egyenlőnek két hallgatót, akiket nem szabadna", s3.equals(s2));
  }
  
  private void hashCode_() {
    assertEquals("A hashCode nem megfelelő hasítókulcsot adott vissza.", access(s1).get("neptun").hashCode(), s1.hashCode());
    assertEquals("A hashCode nem megfelelő hasítókulcsot adott vissza.", access(s2).get("neptun").hashCode(), s2.hashCode());
    assertEquals("A hashCode nem megfelelő hasítókulcsot adott vissza.", access(s3).get("neptun").hashCode(), s3.hashCode());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestStudent() {
    this.suiteName = "Student";
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void setup() {}
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestStudent();
    Test.main(args);
  }
}
