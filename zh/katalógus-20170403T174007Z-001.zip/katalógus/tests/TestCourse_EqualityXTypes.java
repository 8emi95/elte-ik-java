package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import university.entities.Student;
import university.events.Consultation;
import university.events.Lecture;
import university.events.Practice;

public class TestCourse_EqualityXTypes extends Tester {
  private Student s1, s2;
  private Lecture l1;
  private Practice p1;
  private Consultation con1;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
    
    l1 = new Lecture("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    p1 = new Practice("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    con1 = new Consultation("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
  }
  
  @Override
  public void runTests() {
    Test._Environment.runTestCase(new GradedTestCase("Course leszármazottak közötti egyenlőségvizsgálat", () -> equals_(), 2));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void equals_() {
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy előadás megegyezett egy gyakorlattal.", l1.equals(p1));
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy gyakorlat megegyezett egy előadással.", p1.equals(l1));
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy előadás megegyezett egy konzultációval.", l1.equals(con1));
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy konzultáció megegyezett egy előadással.", con1.equals(l1));
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy gyakorlat megegyezett egy konzultációval.", p1.equals(con1));
    assertFalse("A Course leszármazottak equals-a igazat adott, amikor egy konzultáció megegyezett egy gyakorlattal.", con1.equals(p1));
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestCourse_EqualityXTypes() {
    this.suiteName = "Course/equality-across-types";
    
    Test._Environment.createOrLoadDependency(this, new TestLecture());
    Test._Environment.createOrLoadDependency(this, new TestPractice());
    Test._Environment.createOrLoadDependency(this, new TestConsultation());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestCourse_EqualityXTypes();
    Test.main(args);
  }
}
