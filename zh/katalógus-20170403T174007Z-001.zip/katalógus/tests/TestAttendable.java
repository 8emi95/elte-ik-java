package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import university.events.Attendable;

public class TestAttendable extends Tester {
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tInterface felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az interface felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    checkMethod(Attendable.class, "getLean", Modifier.ABSTRACT | Modifier.PUBLIC, int.class);
    checkMethod(Attendable.class, "isAttendanceMandatory", Modifier.ABSTRACT | Modifier.PUBLIC, boolean.class);
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestAttendable() {
    this.suiteName = "Attendable";
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void setup() {}
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestAttendable();
    Test.main(args);
  }
}
