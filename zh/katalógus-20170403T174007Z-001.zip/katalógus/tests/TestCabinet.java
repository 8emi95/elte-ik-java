package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import university.Cabinet;
import university.Roster;
import university.entities.Student;
import university.events.Attendable;
import university.events.Consultation;
import university.events.Course;
import university.events.Lecture;
import university.events.OfficeHour;
import university.events.Practice;

public class TestCabinet extends Tester {
  private Student s1, s5;
  private Lecture lec1;
  private Practice pra1;
  
  private Cabinet cabinet;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s5 = new Student("Alexstrasza", "DTHWNG", new java.util.Random().nextInt(100), new java.util.Random().nextInt(100));
    
    lec1 = new Lecture("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    pra1 = new Practice("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 4;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok", () -> Constructor(), 1));
    Test._Environment.runTestCase(new GradedTestCase("getEvents", () -> getEvents(), 2));
    Test._Environment.runTestCase(new GradedTestCase("addEvent és addRoster", () -> adders(), 4));
    Test._Environment.runTestCase(new GradedTestCase("registerBonus", () -> registerBonus(), 2));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    checkField(Cabinet.class, "rosters", Modifier.PRIVATE | Modifier.FINAL, Map.class);
    checkField(Cabinet.class, "bonus", Modifier.PRIVATE | Modifier.FINAL, Map.class);
    
    checkMethod(Cabinet.class, "addEvent", Modifier.PUBLIC, void.class, Attendable.class);
    checkMethod(Cabinet.class, "addRoster", Modifier.PUBLIC, void.class, Roster.class);
    checkMethod(Cabinet.class, "getEvents", Modifier.PUBLIC, Set.class);
    checkMethod(Cabinet.class, "registerBonus", Modifier.PUBLIC, void.class, Student.class);
    checkMethod(Cabinet.class, "getMissesFor", Modifier.PUBLIC, int.class, Student.class);
  }
  
  private HashMap<String, Object> access(Cabinet s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("rosters");
    fields.add("bonus");
    
    return fullAccess(s, fields);
  }
  
  private void Constructor() {
    cabinet = new Cabinet();
    assertTrue("A konstruktor nem inicializálta az adattagokat.", access(cabinet).get("rosters") != null);
    assertTrue("A konstruktor nem inicializálta az adattagokat.", access(cabinet).get("bonus") != null);
  }
  
  @SuppressWarnings("unchecked")
  private void getEvents() {
    ((Map)access(cabinet).get("rosters")).put(new Lecture("A", "B", "C"), new LinkedList());
    Set<Attendable> get = cabinet.getEvents();
    get.add(new Practice("A", "B", "C"));
    
    assertEquals("A getEvents hatására meg tudtam változtatni a belső reprezentációt, mert hozzáadhattam új kulcsot a Map-hez.", 1, ((Map)access(cabinet).get("rosters")).size());
  }
  
  @SuppressWarnings("unchecked")
  private void addEvent() {
    Map rosters = (Map)access(cabinet).get("rosters");
    rosters.clear();
    
    cabinet.addEvent(lec1);
    assertEquals("Az addEvent nem hozott létre új fiókot a szekrényben.", 1, rosters.size());
    assertEquals("Az addEvent nem hozott létre új fiókot a szekrényben.", new LinkedList<Roster>(), rosters.get(lec1));
    
    LinkedList<Roster> rosterList = (LinkedList<Roster>)rosters.get(lec1);
    rosterList.add(new Roster<Object>(new Object(), 0, 0));
    
    cabinet.addEvent(lec1);
    assertEquals("Az addEvent újra létrehozott egy már létező fiókot.", 1, rosters.size());
    assertEquals("Az addEvent újra létrehozott egy már létező fiókot.", rosterList, rosters.get(lec1));
    assertEquals("Az addEvent újra létrehozott egy már létező fiókot.", 1, rosterList.size());
  }
  
  @SuppressWarnings("unchecked")
  private void addRoster() {
    Map rosters = (Map)access(cabinet).get("rosters");
    
    Roster<Lecture> r2 = new Roster<Lecture>(lec1, 1, 5);
    cabinet.addRoster(r2);
    
    assertEquals("Az addRoster hatására nem került a katalógus hozzáadásra a fiókba.", 2, ((LinkedList<Roster>)rosters.get(lec1)).size());
    
    Roster<Practice> r3 = new Roster<Practice>(pra1, 2, 10);
    cabinet.addRoster(r3);
    assertEquals("Az addRoster nem hozott létre új fiókot a szekrényben, amikor korábban ismeretlen esemény katalógusát adtuk hozzá.", 2, rosters.size());
    assertEquals("Az addRoster az adott jelenléti ívet rossz fiókba tette.", 2, ((LinkedList<Roster>)rosters.get(lec1)).size());
    assertEquals("Az addRoster hatására nem került a katalógus hozzáadásra a fiókba.", 1, ((LinkedList<Roster>)rosters.get(pra1)).size());
  }
  
  private void adders() {
    addEvent();
    addRoster();
  }
  
  @SuppressWarnings("unchecked")
  private void registerBonus() {
    Map<Student, Integer> bonus = (Map<Student, Integer>)access(cabinet).get("bonus");
    assertEquals("A bónuszpontokat tartalmazó adattag kezdetben nem volt üres.", 0, bonus.size());
    
    cabinet.registerBonus(s5);
    assertEquals("A registerBonus az első bónuszpontnál rossz pontszámot jegyzett fel.", 1, bonus.get(s5));
    cabinet.registerBonus(s5);
    assertEquals("A registerBonus a második bónuszpontnál rossz pontszámot jegyzett fel.", 2, bonus.get(s5));
    
    cabinet.registerBonus(s1);
    assertEquals("A registerBonus az első bónuszpontnál rossz pontszámot jegyzett fel.", 1, bonus.get(s1));
    assertEquals("A registerBonus egy új hallgatónál rossz helyre írt be bónuszpontot.", 2, bonus.get(s5));
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestCabinet() {
    this.suiteName = "Cabinet";
    
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    Test._Environment.createOrLoadDependency(this, new TestConsultation());
    Test._Environment.createOrLoadDependency(this, new TestLecture());
    Test._Environment.createOrLoadDependency(this, new TestOfficeHour());
    Test._Environment.createOrLoadDependency(this, new TestPractice());
    Test._Environment.createOrLoadDependency(this, new TestRoster());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestCabinet();
    Test.main(args);
  }
}
