package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.HashMap;

import university.Roster;
import university.entities.Student;

public class TestRoster extends Tester {
  private Student s1, s2;
  private Roster r1, r2;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 3;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok", () -> Constructor(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Getterek", () -> Getters(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Gyűjteményvezérlés", () -> CollectionHandling(), 4));
    Test._Environment.runTestCase(new GradedTestCase("toString", () -> toString_(), 2));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    assertEquals("A Roster nem rendelkezik a megfelelő generikus típusparaméterrel.", 1, Roster.class.getTypeParameters().length);
    
    Class clazz_generic_upperBound;
    try {
      clazz_generic_upperBound = Class.forName(Roster.class.getTypeParameters()[0].getBounds()[0].getTypeName());
    } catch (Exception e) { throw new RuntimeException(e); }
    
    
    checkField(Roster.class, "event", Modifier.PRIVATE | Modifier.FINAL, clazz_generic_upperBound);
    checkField(Roster.class, "day", Modifier.PRIVATE | Modifier.FINAL, int.class);
    checkField(Roster.class, "roster", Modifier.PRIVATE | Modifier.FINAL, Collection.class);
    
    checkMethod(Roster.class, "hasAttended", Modifier.PUBLIC, boolean.class, Student.class);
    checkMethod(Roster.class, "attend", Modifier.PUBLIC, void.class, Student.class);
    checkMethod(Roster.class, "getEvent", Modifier.PUBLIC, clazz_generic_upperBound);
    checkMethod(Roster.class, "getDay", Modifier.PUBLIC, int.class);
    checkMethod(Roster.class, "toString", Modifier.PUBLIC, String.class);
  }
  
  private HashMap<String, Object> access(Roster s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("event");
    fields.add("day");
    fields.add("roster");
    
    return fullAccess(s, Roster.class, fields);
  }
  
  /*private class _C extends Roster {
    public _C(String a, String b, String c) { super(a, b, c); }
    public boolean equals(Object a) { return false; }
    public int hashCode() { return 0; }
  }*/
  
  private void Constructor() {
    r1 = new Roster<Object>(new String("Java ZH"), 0, 25);
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Java ZH", (String)access(r1).get("event"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, (int)access(r1).get("day"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, ((Collection)access(r1).get("roster")).size());
  }
  
  private void Getters() {
    assertEquals("A getEvent metódus hibás választ adott.", "Java ZH", r1.getEvent());
    assertEquals("A getDay metódus hibás választ adott.", 0, r1.getDay());
  }
  
  private void CollectionHandling() {
    Collection access_ = ((Collection)access(r1).get("roster"));
    
    r1.attend(s1);
    assertEquals("Az attend nem írta alá a katalógust.", 1, access_.size());
    assertTrue("Az attend nem írta alá a katalógust.", access_.contains(s1));
    
    r1.attend(s1);
    assertEquals("Az attend megengedte, hogy a katalógust kétszer aláírják.", 1, access_.size());
    assertTrue("Az attend kitörölte a hallgató aláírását amikor másodjára is megpróbált aláírni.", access_.contains(s1));
    
    r1.attend(s2);
    assertEquals("Az attend nem írta alá a katalógust.", 2, access_.size());
    assertTrue("Az attend az új hallgató aláírásakor elveszítette a régiét.", r1.hasAttended(s1));
    assertTrue("Az attend nem írta alá a katalógust.", access_.contains(s2));
  
    assertTrue("Az hasAttended hamis választ adott, pedig a hallgató aláírta a katalógust.", r1.hasAttended(s1));
    assertTrue("Az hasAttended hamis választ adott, pedig a hallgató aláírta a katalógust.", r1.hasAttended(s2));
    
    Student s3 = new Student("BLABLA", "Asdf Jklé");
    assertFalse("Az hasAttended igaz választ adott, pedig a hallgató nem írta a katalógust.", r1.hasAttended(s3));
    
    // Remove some students and check again...
    access_.clear();
    assertEquals("A feliratkozott hallgatókm létszáma nem csökkent, amikor a katalógust összetépték.", 0, access_.size());
    assertFalse("Az hasAttended igaz választ adott, pedig a hallgató nem írta a katalógust.", r1.hasAttended(s1));
    assertFalse("Az hasAttended igaz választ adott, pedig a hallgató nem írta a katalógust.", r1.hasAttended(s2));
    assertFalse("Az hasAttended igaz választ adott, pedig a hallgató nem írta a katalógust.", r1.hasAttended(s3));
    
    // ... and re-add them for later on
    r1.attend(s1);
    r1.attend(s2);
    r1.attend(s3);
  }
  
  private void toString_() {
    String ts1 = "Whisperity Dypertkova,WHISPY";
    String ts2 = "BLABLA,Asdf Jklé";
    String ts3 = "Gipsz Jakab,BATMAN";

    String[] res = r1.toString().split("\n");
    assertEquals("A toString hibás Stringet adott vissza.", 4, res.length);
    assertEquals("A toString hibás Stringet adott vissza.", "Java ZH/0:", res[0]);

    List<String> resL = Arrays.asList(res);
    assertTrue("A toString nem tartalmazta a '" + ts1 + "' hallgatót, pedig aláírta a katalógust.", resL.contains(ts1));
    assertTrue("A toString nem tartalmazta a '" + ts2 + "' hallgatót, pedig aláírta a katalógust.", resL.contains(ts2));
    assertTrue("A toString nem tartalmazta a '" + ts3 + "' hallgatót, pedig aláírta a katalógust.", resL.contains(ts3));

    Roster r2 = new Roster<Integer>(15, 5, 0);
    r2.attend(s1);
    assertEquals("A toString hibás Stringet adott vissza.", "15/5:\nWhisperity Dypertkova,WHISPY", r2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestRoster() {
    this.suiteName = "Roster";
    
    Test._Environment.createOrLoadDependency(this, new TestStudent());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestRoster();
    Test.main(args);
  }
}
