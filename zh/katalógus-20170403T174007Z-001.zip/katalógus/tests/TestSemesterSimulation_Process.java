package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.StringJoiner;

import university.SemesterSimulation;

public class TestSemesterSimulation_Process extends Tester {
  private SemesterSimulation ss0, ss1;
  
  @Override public void setup() {
    ss0 = Test._Environment.getGlobal("SS_0");
    ss1 = Test._Environment.getGlobal("SS_1");
  }
  
  @Override
  public void runTests() {
    assertTrue("Az előkészítési fázis meghiúsult.", ss0 != null);
    assertTrue("Az előkészítési fázis meghiúsult.", ss1 != null);
    
    System.out.println("\tA tesztegység automatikus tesztelése nem végezhető el a tesztkörnyezet által!");
    System.out.println("\tA feladat megvalósításáért maximum 10 pont jár, amelyet a gyakorlatvezető fog kiosztani a feladatmegoldásod ismeretében.");
    System.out.println("\n\tNéhány példa-kimenet generálása következik:\n--------------------------------------");
    
    ss0.process();
    System.out.println("--------------------------------------");
    ss1.process();
    System.out.println("--------------------------------------");
    
    Random rnd = new Random();
    SemesterSimulation ss2 = new SemesterSimulation();
    ArrayList<String> courseCodes = new ArrayList<String>();
    
    {
      HashMap<String, String> courses = new HashMap<String, String>();
      int target = 10 + rnd.nextInt(30);
      
      for (int i = 0; i < target; ++i) {
        String cName = java.util.UUID.randomUUID().toString();
        String cCode = java.util.UUID.randomUUID().toString();
        String prof = java.util.UUID.randomUUID().toString();
        
        courseCodes.add(cCode);
        String cType = "";
        while (cType.equals("")) {
          int rndInt = rnd.nextInt(100) + 1;
          if (rndInt % 2 == 0) {
            cType += "L";
          }
          if (rndInt % 3 == 0) {
            cType += "P";
          }
          if (rndInt % 5 == 0) {
            cType += "C";
          }
        }
        
        courses.put("[" + cType + "]" + cName + "(" + cCode + ")", prof);
      }
      
      ss2.prepareCourses(courses);
    }
    
    {
      HashMap<String, String> students = new HashMap<String, String>();
      
      int target = 40 + rnd.nextInt(100);
      
      for (int i = 0; i < target; ++i) {
        String name = java.util.UUID.randomUUID().toString().substring(0, 13);
        String neptun = java.util.UUID.randomUUID().toString().substring(10, 17).replace("-", "").toUpperCase();
        int spirit = rnd.nextInt(100) + 1, sloth = rnd.nextInt(100) + 1;
        
        int numSubjects = rnd.nextInt(courseCodes.size());
        Collections.shuffle(courseCodes);
        StringJoiner sj = new StringJoiner("|");
        for (int j = 0; j < numSubjects; ++j) {
          sj.add(courseCodes.get(j));
        }
        
        students.put(name + "," + neptun + "," + spirit + "," + sloth, sj.toString());
      }
      
      ss2.prepareStudents(students);
    }
   
    ss2.process();
  }
  
  @Override public void teardown() {
    Test._Environment.setGlobal("SS_0", null);
    Test._Environment.setGlobal("SS_1", null);
  }
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  
  TestSemesterSimulation_Process() {
    this.suiteName = "SemesterSimulation/Process";
    
    Test._Environment.createOrLoadDependency(this, new TestSemesterSimulation_Prepare());
    Test._Environment.createOrLoadDependency(this, new TestFacultyDay());
    // A Cabinet_getMissesFor helyes működését itt most nem várjuk el. Még ha rosszul is működne a Cabinet#getMissesFor() metódusa, egy kiíratást csak el tud végezni esetleg valami beégetett adattal. :D
    
    Test._Environment.registerSuite(this);
  }
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestSemesterSimulation_Process();
    Test.main(args);
  }
}
