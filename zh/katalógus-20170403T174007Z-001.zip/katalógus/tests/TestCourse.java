package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import university.entities.Student;
import university.events.Course;

public class TestCourse extends Tester {
  private Student s1, s2;
  private Course c1;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 3;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok", () -> Constructor(), 2));
    Test._Environment.runTestCase(new GradedTestCase("Getterek", () -> Getters(), 2));
    Test._Environment.runTestCase(new GradedTestCase("addStudent", () -> addStudent(), 3));
    Test._Environment.runTestCase(new GradedTestCase("isStudentSubscribedTo", () -> isStudentSubscribedTo(), 1));
    Test._Environment.runTestCase(new GradedTestCase("toString", () -> toString_(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    assertTrue("A Course osztályból lehet példányokat létrehozni.", Modifier.isAbstract(Course.class.getModifiers()));
    
    checkField(Course.class, "courseCode", Modifier.PROTECTED | Modifier.FINAL, String.class);
    checkField(Course.class, "name", Modifier.PRIVATE | Modifier.FINAL, String.class);
    checkField(Course.class, "professor", Modifier.PRIVATE | Modifier.FINAL, String.class);
    checkField(Course.class, "students", Modifier.PRIVATE | Modifier.FINAL, Collection.class);
    
    checkMethod(Course.class, "getCourseCode", Modifier.PUBLIC, String.class);
    checkMethod(Course.class, "getName", Modifier.PUBLIC, String.class);
    checkMethod(Course.class, "getProfessor", Modifier.PUBLIC, String.class);
    checkMethod(Course.class, "getStudents", Modifier.PUBLIC, Collection.class);
    checkMethod(Course.class, "studentCount", Modifier.PUBLIC, int.class);
    checkMethod(Course.class, "addStudent", Modifier.PUBLIC, void.class, Student.class);
    checkMethod(Course.class, "isStudentSubscribedTo", Modifier.PUBLIC, boolean.class, Student.class);
    checkMethod(Course.class, "equals", Modifier.PUBLIC | Modifier.ABSTRACT, boolean.class, Object.class);
    checkMethod(Course.class, "hashCode", Modifier.PUBLIC | Modifier.ABSTRACT, int.class);
  }
  
  private HashMap<String, Object> access(Course s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("courseCode");
    fields.add("name");
    fields.add("professor");
    fields.add("students");
    
    return fullAccess(s, Course.class, fields);
  }
  
  private class _C extends Course {
    public _C(String a, String b, String c) { super(a, b, c); }
    public boolean equals(Object a) { return false; }
    public int hashCode() { return 0; }
  }
  
  private void Constructor() {
    c1 = new _C("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "IP-08cPNY2EG", (String)access(c1).get("courseCode"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Programozási nyelvek II. - JAVA", (String)access(c1).get("name"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Kozsik Tamás", (String)access(c1).get("professor"));
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, ((Collection)access(c1).get("students")).size());
  }
  
  private void Getters() {
    assertEquals("A getCourseCode metódus hibás választ adott.", "IP-08cPNY2EG", c1.getCourseCode());
    assertEquals("A getName metódus hibás választ adott.", "Programozási nyelvek II. - JAVA", c1.getName());
    assertEquals("A getProfessor metódus hibás választ adott.", "Kozsik Tamás", c1.getProfessor());
    assertEquals("A studentCount metódus hibás választ adott.", 0, c1.studentCount());
  }
  
  private void addStudent() {
    c1.addStudent(s1);
    assertEquals("Az addStudent nem adta hozzá az újonnan jött hallgatót.", 1, c1.studentCount());
    assertTrue("Az addStudent nem adta hozzá az újonnan jött hallgatót.", c1.getStudents().contains(s1));
    
    c1.addStudent(s1);
    assertEquals("Az addStudent hozzáadta ugyanazt a hallgatót kétszer.", 1, c1.studentCount());
    assertTrue("Az addStudent nem adta hozzá az újonnan jött hallgatót.", c1.getStudents().contains(s1));
    
    c1.addStudent(s2);
    assertEquals("Az addStudent nem adta hozzá az újonnan jött hallgatót.", 2, c1.studentCount());
    assertTrue("Az addStudent az új hallgató hozzáadásakor elveszítette a régit.", c1.getStudents().contains(s1));
    assertTrue("Az addStudent nem adta hozzá az újonnan jött hallgatót.", c1.getStudents().contains(s2));
  }
  
  private void isStudentSubscribedTo() {
    assertTrue("Az isStudentSubscribedTo hamis választ adott, pedig a hallgató felvette a tárgyat.", c1.isStudentSubscribedTo(s1));
    assertTrue("Az isStudentSubscribedTo hamis választ adott, pedig a hallgató felvette a tárgyat.", c1.isStudentSubscribedTo(s2));
    
    Student s3 = new Student("BLABLA", "Asdf Jklé");
    assertFalse("Az isStudentSubscribedTo igaz választ adott, pedig a hallgató nem vette fel a tárgyat.", c1.isStudentSubscribedTo(s3));
    
    // Remove some students and check again...
    ((Collection)access(c1).get("students")).clear();
    assertEquals("A hallgatók létszáma nem csökkent, amikor a Tanulmányi Hivatal vezetője törölte a hallgatók jelentkezését.", 0, c1.studentCount());
    assertFalse("Az isStudentSubscribedTo igaz választ adott, pedig a hallgató nem vette fel a tárgyat.", c1.isStudentSubscribedTo(s1));
    assertFalse("Az isStudentSubscribedTo igaz választ adott, pedig a hallgató nem vette fel a tárgyat.", c1.isStudentSubscribedTo(s2));
    assertFalse("Az isStudentSubscribedTo igaz választ adott, pedig a hallgató nem vette fel a tárgyat.", c1.isStudentSubscribedTo(s3));
    
    // ... and re-add them for later on
    addStudent();
  }
  
  private void toString_() {
    assertEquals("A toString hibás Stringet adott vissza.", "(2)Programozási nyelvek II. - JAVA[IP-08cPNY2EG](Kozsik Tamás)", c1.toString());
    
    Course c2 = new _C("Foo", "Bar Baz", "Qux");
    assertEquals("A toString hibás Stringet adott vissza.", "(0)Bar Baz[Foo](Qux)", c2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestCourse() {
    this.suiteName = "Course";
    
    Test._Environment.createOrLoadDependency(this, new TestStudent());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestCourse();
    Test.main(args);
  }
}
