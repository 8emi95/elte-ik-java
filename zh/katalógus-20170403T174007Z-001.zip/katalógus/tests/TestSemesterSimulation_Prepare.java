package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import university.Cabinet;
import university.Roster;
import university.SemesterSimulation;
import university.entities.Student;
import university.events.Attendable;
import university.events.Consultation;
import university.events.Course;
import university.events.Lecture;
import university.events.OfficeHour;
import university.events.Practice;

public class TestSemesterSimulation_Prepare extends Tester {
  private SemesterSimulation ss0, ss1;
  
  @Override
  public void runTests() {
    try {
      int pointValue = 2;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktor", () -> Constructor(), 1));
    Test._Environment.runTestCase(new GradedTestCase("prepareCourses", () -> prepareCourses(), 4));
    Test._Environment.runTestCase(new GradedTestCase("prepareStudents", () -> prepareStudents(), 4));
  }
  
  @Override public void teardown() {
    Test._Environment.setGlobal("SS_0", ss0);
    Test._Environment.setGlobal("SS_1", ss1);
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    checkField(SemesterSimulation.class, "cabinet", Modifier.PRIVATE | Modifier.FINAL, Cabinet.class);
    checkField(SemesterSimulation.class, "students", Modifier.PRIVATE | Modifier.FINAL, Collection.class);
    
    checkMethod(SemesterSimulation.class, "prepareCourses", Modifier.PUBLIC, void.class, Map.class);
    checkMethod(SemesterSimulation.class, "prepareStudents", Modifier.PUBLIC, void.class, Map.class);
  }
  
  private HashMap<String, Object> access(SemesterSimulation s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("cabinet");
    fields.add("students");
    
    return fullAccess(s, fields);
  }
  
  private void Constructor() {
    ss0 = new SemesterSimulation();
    assertTrue("A konstruktor nem inicializálta az adattagokat.", access(ss0).get("cabinet") != null);
    assertTrue("A konstruktor nem inicializálta az adattagokat.", access(ss0).get("students") != null);
    
    ss1 = new SemesterSimulation();
  }
  
  private void prepareCourses() {
    {
      Map<String, String> m0 = new HashMap<String, String>();
      m0.put("[L]LPC(?)", "Whisperity Dypertkova");
      m0.put("[P]CPL(!)", "Whisperity Dypertkova");
      
      ss0.prepareCourses(m0);
      
      assertEquals("Nem megfelelő számú fiók jött létre a katalógusos szekrényben.", 3, _cabinetRosters(ss0).size());
      
      _checkCourse(_cabinetRosters(ss0), "(0)LPC[?](Whisperity Dypertkova){Előadás}");
      _checkCourse(_cabinetRosters(ss0), "(0)CPL[!](Whisperity Dypertkova){Gyakorlat}");
      _checkOfficeHour(_cabinetRosters(ss0), "Whisperity Dypertkova");
    }
  
    // --------------------------
    {
      Map<String, String> m1 = new HashMap<String, String>();
      m1.put("[LPC]Java(IP-08cPNY2EG)", "Kozsik Tamás");
      m1.put("[LLL]Fonya(IP-08cFNYE)", "Csuhaj-Varjú Erzsébet");
      m1.put("[LPPL]C++(IP-08cPNY1EG)", "Pataki Norbert");
      m1.put("[LPPL]C++(IP-08cPNY1EG)", "Pataki Norbert");
      m1.put("[C]Funkcionális programozás(IP-08bFUNPEG)", "Bozó István");
      
      ss1.prepareCourses(m1);
      
      assertEquals("Nem megfelelő számú fiók jött létre a katalógusos szekrényben.", 11, _cabinetRosters(ss1).size());
      
      _checkCourse(_cabinetRosters(ss1), "(0)Fonya[IP-08cFNYE](Csuhaj-Varjú Erzsébet){Előadás}");
      _checkCourse(_cabinetRosters(ss1), "(0)C++[IP-08cPNY1EG](Pataki Norbert){Gyakorlat}");
      _checkCourse(_cabinetRosters(ss1), "(0)C++[IP-08cPNY1EG](Pataki Norbert){Előadás}");
      _checkCourse(_cabinetRosters(ss1), "(0)Java[IP-08cPNY2EG](Kozsik Tamás){Előadás}");
      _checkCourse(_cabinetRosters(ss1), "(0)Java[IP-08cPNY2EG](Kozsik Tamás){Konzultáció}");
      _checkCourse(_cabinetRosters(ss1), "(0)Funkcionális programozás[IP-08bFUNPEG](Bozó István){Konzultáció}");
      _checkCourse(_cabinetRosters(ss1), "(0)Java[IP-08cPNY2EG](Kozsik Tamás){Gyakorlat}");
      _checkOfficeHour(_cabinetRosters(ss1), "Kozsik Tamás");
      _checkOfficeHour(_cabinetRosters(ss1), "Pataki Norbert");
      _checkOfficeHour(_cabinetRosters(ss1), "Csuhaj-Varjú Erzsébet");
      _checkOfficeHour(_cabinetRosters(ss1), "Bozó István");
    }
  }
 
  
  private void prepareStudents() {
    {
      Map<String, String> s0 = new HashMap<String, String>();
      s0.put("Jóska Pista,APISTI", "?|!");
      s0.put("Mikecz Márk,LOCU00,0,100", "?");
      s0.put("Soha Péter,SOHAPT,100,100", "!");
      
      ss0.prepareStudents(s0);
      
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss0, "Jóska Pista", "APISTI", 75, 50));
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss0, "Mikecz Márk", "LOCU00", 0, 100));
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss0, "Soha Péter", "SOHAPT", 100, 100));
      
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss0, "APISTI", "(2)CPL[!](Whisperity Dypertkova){Gyakorlat}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss0, "SOHAPT", "(2)CPL[!](Whisperity Dypertkova){Gyakorlat}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss0, "APISTI", "(2)LPC[?](Whisperity Dypertkova){Előadás}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss0, "LOCU00", "(2)LPC[?](Whisperity Dypertkova){Előadás}"));
    }
    
    // ------------------- 
    {
      Map<String, String> s1 = new HashMap<String, String>();
      s1.put("Whisperity Dypertkova,WHISPY,100,0", "IP-08cPNY2EG|IP-08bFUNPEG|IP-08bPNY1EG|IP-08cPNY1EG"); // <- There's no IP-08bPNY1EG
      s1.put("Mikecz Márk,LOCU00,0,100", "");
      s1.put("Soha Péter,SOHAPT,100,100", "IP-08cPNY1EG|IP-08cFNYE");
      
      ss1.prepareStudents(s1);
      
      assertEquals("A prepareStudents felvett egy olyan tárgyat, amely eredetileg nem létezett, csak egy hallgató jelentkezett rá.", 11, _cabinetRosters(ss1).size());
      
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss1, "Whisperity Dypertkova", "WHISPY", 100, 0));
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss1, "Mikecz Márk", "LOCU00", 0, 100));
      assertEquals("A prepareStudents nem vette fel a hallgatót, vagy egynél többször vette fel.", 1, _checkContainsStudent(ss1, "Soha Péter", "SOHAPT", 100, 100));
      
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "SOHAPT", "(1)Fonya[IP-08cFNYE](Csuhaj-Varjú Erzsébet){Előadás}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(1)Funkcionális programozás[IP-08bFUNPEG](Bozó István){Konzultáció}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "SOHAPT", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Gyakorlat}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Gyakorlat}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "SOHAPT", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Előadás}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Előadás}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Előadás}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Gyakorlat}"));
      assertTrue("A prepareStudents nem vette fel egy hallgatónak az egyik tárgyát.", _checkStudentSubscribedTo(ss1, "WHISPY", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Konzultáció}"));
      
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(1)Fonya[IP-08cFNYE](Csuhaj-Varjú Erzsébet){Előadás}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(1)Funkcionális programozás[IP-08bFUNPEG](Bozó István){Konzultáció}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Gyakorlat}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(2)C++[IP-08cPNY1EG](Pataki Norbert){Előadás}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Előadás}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Gyakorlat}"));
      assertFalse("A prepareStudents felvett olyan tárgyakat, amelyeket nem kellett volna.", _checkStudentSubscribedTo(ss1, "LOCU00", "(1)Java[IP-08cPNY2EG](Kozsik Tamás){Konzultáció}"));
    }
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  @SuppressWarnings("unchecked")
  private Map<Attendable, LinkedList<Roster>> _cabinetRosters(SemesterSimulation ss) {
    // Access the inner represenation!
    Cabinet c = (Cabinet)access(ss).get("cabinet");
    
    ArrayList<String> fields = new ArrayList<String>(1);
    fields.add("rosters");
    Map<Attendable, LinkedList<Roster>> cr = (Map<Attendable, LinkedList<Roster>>)fullAccess(c, Cabinet.class, fields).get("rosters");
    
    return cr;
  }
  
  private boolean _checkCourse(Map<Attendable, LinkedList<Roster>> cabinetRosters, String toString) {
    boolean good = false;
    
    for (Map.Entry<Attendable, LinkedList<Roster>> e : cabinetRosters.entrySet()) {
      assertTrue("A félév inicializációjakor létrejöttek katalógusok a szekrényben.", e.getValue().size() == 0);
      
      if (e.getKey().toString().equals(toString))
        good = true;
    }
    
    return good;
  }
  
  private boolean _checkOfficeHour(Map<Attendable, LinkedList<Roster>> cabinetRosters, String prof) {
    boolean good = false;
    for (Map.Entry<Attendable, LinkedList<Roster>> e : cabinetRosters.entrySet()) {
      if (!(e.getKey() instanceof OfficeHour))
        continue;
      
      assertTrue("A félév inicializációjakor létrejöttek katalógusok a szekrényben.", e.getValue().size() == 0);
      
      if (((OfficeHour)e.getKey()).getProfessor().equals(prof))
        good = true;
    }
    
    return good;
  }
  
  @SuppressWarnings("unchecked")
  private int _checkContainsStudent(SemesterSimulation ss, String name, String neptun, int spirit, int sloth) {
    Collection<Student> students = (Collection<Student>)access(ss).get("students");

    int count = 0;
    for (Student s : students)
      if (s.getName().equals(name) && s.getNeptun().equals(neptun) && s.getSpirit() == spirit && s.getSloth() == sloth)
        ++count;
  
    return count;
  }
  
  private boolean _checkStudentSubscribedTo(SemesterSimulation ss, String neptun, String courseString) {
    for (Map.Entry<Attendable, LinkedList<Roster>> e : _cabinetRosters(ss).entrySet()) {
      if (!(e.getKey() instanceof Course))
        continue;
      
      if (e.getKey().toString().equals(courseString))
        for (Student s : ((Course)e.getKey()).getStudents())
          if (s.getNeptun().equals(neptun))
            return true;
    }
    
    return false;
  }
  
  TestSemesterSimulation_Prepare() {
    this.suiteName = "SemesterSimulation/Prepare";
    
    Test._Environment.createOrLoadDependency(this, new TestStudent_Desire());
    Test._Environment.createOrLoadDependency(this, new TestCabinet());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void setup() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestSemesterSimulation_Prepare();
    Test.main(args);
  }
}
