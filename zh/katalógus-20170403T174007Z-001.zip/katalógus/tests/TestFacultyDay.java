package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;

import university.events.FacultyDay;

public class TestFacultyDay extends Tester {
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void Reflection() {
    assertEquals("A FacultyDay leszármazik valamiből.", Object.class, FacultyDay.class.getSuperclass());
    assertEquals("A FacultyDay osztálynak van adattagja.", 0, FacultyDay.class.getDeclaredFields().length);
    assertEquals("A FacultyDay osztálynak van metódusa.", 0, FacultyDay.class.getDeclaredMethods().length);
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestFacultyDay() {
    this.suiteName = "FacultyDay";
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void setup() {}
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestFacultyDay();
    Test.main(args);
  }
}
