package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;

import university.entities.Student;
import university.events.Attendable;
import university.events.Lecture;

public class TestLecture extends Tester {
  private Student s1, s2;
  private Lecture l1, l2;
  
  @Override public void setup() {
    s1 = new Student("Whisperity Dypertkova", "WHISPY");
    s2 = new Student("Gipsz Jakab", "BATMAN", 0, 100);
  }
  
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok, getterek", () -> _CtorAndGetter(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Object-ből örökölt három metódus", () -> _EqualitySet(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void _CtorAndGetter() {
    Constructor();
    Getters();
  }
  
  private void _EqualitySet() {
    equals_();
    hashCode_();
    toString_();
  }
  
  private void Reflection() {
    assertTrue("A Lecture osztály nem implementálja az Attendable interfészt.", Attendable.class.isAssignableFrom(Lecture.class));
    
    checkMethod(Lecture.class, "getLean", Modifier.PUBLIC, int.class);
    checkMethod(Lecture.class, "isAttendanceMandatory", Modifier.PUBLIC, boolean.class);
    checkMethod(Lecture.class, "equals", Modifier.PUBLIC, boolean.class, Object.class);
    checkMethod(Lecture.class, "hashCode", Modifier.PUBLIC, int.class);
    checkMethod(Lecture.class, "toString", Modifier.PUBLIC, String.class);
  }
  
  private void Constructor() {
    l1 = new Lecture("IP-08cPNY2EG", "Programozási nyelvek II. - JAVA", "Kozsik Tamás");
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "IP-08cPNY2EG", l1.getCourseCode());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Programozási nyelvek II. - JAVA", l1.getName());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Kozsik Tamás", l1.getProfessor());
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", 0, l1.getStudents().size());
    
    l2 = new Lecture("Foo", "Bar Baz", "Qux");
  }
  
  private void Getters() {
    assertEquals("A getLean metódus hibás választ adott.", 60, l1.getLean());
    assertEquals("A isAttendanceMandatory metódus hibás választ adott.", true, l1.isAttendanceMandatory());
  }
  
  private void equals_() {
    assertFalse("Az equals egyenlőnek talált két eltérő tárgykódú előadást.", l1.equals(l2));
    Lecture l3 = new Lecture("IP-08cPNY2EG", "Jáva EA", "Jáva Tanszék");
    assertTrue("Az equals nem talált egyenlőnek talált két azonos tárgykódú előadást.", l1.equals(l3));
    
    assertFalse("Az equals rossz választ ad eltérő típusok esetén.", l1.equals(new String("IP-08cPNY2EG")));
  }
  
  private void hashCode_() {
    assertEquals("A hashCode hibás választ adott.", new String("IP-08cPNY2EG").hashCode() * 10, l1.hashCode());
    assertEquals("A hashCode hibás választ adott.", new String("Foo").hashCode() * 10, l2.hashCode());
  }
  
  private void toString_() {
    l1.addStudent(s1);
    l1.addStudent(s2);
    
    assertEquals("A toString hibás Stringet adott vissza.", "(2)Programozási nyelvek II. - JAVA[IP-08cPNY2EG](Kozsik Tamás){Előadás}", l1.toString());
    
    assertEquals("A toString hibás Stringet adott vissza.", "(0)Bar Baz[Foo](Qux){Előadás}", l2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestLecture() {
    this.suiteName = "Lecture";
    
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    Test._Environment.createOrLoadDependency(this, new TestCourse());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestLecture();
    Test.main(args);
  }
}
