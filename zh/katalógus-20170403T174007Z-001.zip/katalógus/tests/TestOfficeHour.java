package tests;

import hu.elte.inf.pnyf.whisperity.tester.*;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;

import university.entities.Student;
import university.events.Attendable;
import university.events.OfficeHour;

public class TestOfficeHour extends Tester {
  private OfficeHour oh1, oh2;
  
  @Override
  public void runTests() {
    try {
      int pointValue = 1;
      Reflection();
      System.out.println("\tOsztály felépítése megfelelő. (" + pointValue + " pont)");
      ((GradingTestEnvironment)Test._Environment).addPoints(pointValue);
    } catch (TestCaseException tce) {
      System.out.println("Az osztály felépítése nem felel meg minden, a feladatkiírásban szereplő követelménynek.");
    }
    
    Test._Environment.runTestCase(new GradedTestCase("Konstruktorok, getterek", () -> _CtorAndGetter(), 1));
    Test._Environment.runTestCase(new GradedTestCase("Object-ből örökölt három metódus", () -> _EqualitySet(), 1));
  }
  
  /* ********************* */
  /* *** A tesztesetek *** */
  /* ********************* */
  
  private void _CtorAndGetter() {
    Constructor();
    Getters();
  }
  
  private void _EqualitySet() {
    equals_();
    hashCode_();
    toString_();
  }
  
  private void Reflection() {
    assertTrue("A OfficeHour osztály nem implementálja az Attendable interfészt.", Attendable.class.isAssignableFrom(OfficeHour.class));
    
    checkField(OfficeHour.class, "professor", Modifier.PRIVATE | Modifier.FINAL, String.class);
    
    checkMethod(OfficeHour.class, "getLean", Modifier.PUBLIC, int.class);
    checkMethod(OfficeHour.class, "isAttendanceMandatory", Modifier.PUBLIC, boolean.class);
    checkMethod(OfficeHour.class, "equals", Modifier.PUBLIC, boolean.class, Object.class);
    checkMethod(OfficeHour.class, "hashCode", Modifier.PUBLIC, int.class);
    checkMethod(OfficeHour.class, "toString", Modifier.PUBLIC, String.class);
  }
  
  private HashMap<String, Object> access(OfficeHour s) {
    ArrayList<String> fields = new ArrayList<String>(4);
    fields.add("professor");
    
    return fullAccess(s, fields);
  }
  
  private void Constructor() {
    oh1 = new OfficeHour("Kozsik Tamás");
    
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Kozsik Tamás", (String)access(oh1).get("professor"));
    
    oh2 = new OfficeHour("Qux");
    assertEquals("A konstruktor nem megfelelően inicializálta az adattagokat.", "Qux", (String)access(oh2).get("professor"));
  }
  
  private void Getters() {
    assertEquals("A getProfessor metódus hibás választ adott.", "Kozsik Tamás", oh1.getProfessor());
    assertEquals("A getProfessor metódus hibás választ adott.", "Qux", oh2.getProfessor());
    assertEquals("A getLean metódus hibás választ adott.", 5, oh1.getLean());
    assertEquals("A isAttendanceMandatory metódus hibás választ adott.", false, oh1.isAttendanceMandatory());
  }
  
  private void equals_() {
    assertFalse("Az equals egyenlőnek talált két eltérő oktatójú fogadóórát.", oh1.equals(oh2));
    OfficeHour oh3 = new OfficeHour("Kozsik Tamás");
    assertTrue("Az equals nem talált egyenlőnek talált két azonos oktatójú fogadóórát.", oh1.equals(oh3));
    
    assertFalse("Az equals rossz választ ad eltérő típusok esetén.", oh1.equals(new String("Kozsik Tamás")));
  }
  
  private void hashCode_() {
    assertEquals("A hashCode hibás választ adott.", new String("Kozsik Tamás").hashCode(), oh1.hashCode());
    assertEquals("A hashCode hibás választ adott.", new String("Qux").hashCode(), oh2.hashCode());
  }
  
  private void toString_() {
    assertEquals("A toString hibás Stringet adott vissza.", "Kozsik Tamás{Fogadóóra}", oh1.toString());
    
    assertEquals("A toString hibás Stringet adott vissza.", "Qux{Fogadóóra}", oh2.toString());
  }
  
  /* ************************** */
  /* *** A tesztesetek VÉGE *** */
  /* ************************** */
  
  /* **************************************************************************************** */
  // Az alábbi kódrészletek segédfüggvények a tesztelő működéséhez, NE változtasd meg ezeket!
  /* **************************************************************************************** */
  TestOfficeHour() {
    this.suiteName = "OfficeHour";
    
    Test._Environment.createOrLoadDependency(this, new TestAttendable());
    
    Test._Environment.registerSuite(this);
  }
  
  @Override public void setup() {}
  @Override public void teardown() {}
  
  public static void main(String[] args) {
    Test.createEnv();
    new TestOfficeHour();
    Test.main(args);
  }
}
