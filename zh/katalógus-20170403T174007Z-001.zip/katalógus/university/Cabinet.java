package university;

import java.util.*;

public class Cabinet{
	
	private final Map<Attendable, LinkedList<Roster>> rosters;
	private final Map<Student, Integer> bonus;
	
	public Cabinet(){
		rosters = new HashMap<Attendable, LinkedList<Roster>>();
		bonus = new HashMap<Student, Integer>();
	}
	
	public void addEvent(Attendable a){
		if(!rosters.containsKey(a)){
			rosters.put(a, new LinkedList<Roster>);
		}
	}
	
	public void addEvent(Roster r){
		
	}
	
}