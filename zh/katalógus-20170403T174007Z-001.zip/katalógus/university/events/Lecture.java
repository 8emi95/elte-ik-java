package university.events;

public class Lecture extends Course implements Attendable{
	
	public Lecture(String courseCode, String name, String professor){
		super(courseCode,name,professor);
	}
	
	public int getLean(){
		return 60;
	}
	
	public boolean isAttendanceMandatory(){
		return true;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this){
			return true;
		}
		if(o == null){
			return false;
		}
		if(o.getClass().equals(this.getClass())){
			Lecture l = (Lecture)o;
			return l.getCourseCode() == super.getCourseCode();
		}
		else{
			return false;
		}
	}
	
	@Override
	public int hashCode(){
		return super.getCourseCode().hashCode()*10;
	}
	
	@Override
	public String toString(){
		return super.toString() + "{Előadás}";
	}
}