package university.events;

import university.entities.*;
import java.util.HashSet;

public abstract class Course{
	
	private String courseCode;
	private String name;
	private String professor;
	private HashSet<Student> students;
	
	public Course(String courseCode, String name, String professor){
		this.courseCode = courseCode;
		this.name = name;
		this.professor = professor;
		students = new HashSet<>();
	}
	
	public String getCourseCode(){
		return courseCode;
	}
	
	public String getName(){
		return name;
	}
	
	public String getProfessor(){
		return professor;
	}
	
	public HashSet<Student> getStudents(){
		return new HashSet<Student>(students);
	}
	
	public int studentCount(){
		return students.size();
	}
	
	public void addStudent(Student s){
		students.add(s);
	}
	
	public boolean isStudentSubscribedTo(Student s){
		for(Student valami : students){
			if(s.equals(valami)){
				return true;
			}
		}
		return false;
	}
	
	@Override public abstract boolean equals(Object o);
	@Override public abstract int hashCode();
	
	@Override
	public String toString(){
		return "(" + studentCount() + ")" + name + "[" + courseCode + "](" + professor + ")";
	}
}