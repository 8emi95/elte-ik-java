package university.events;

public class Practice extends Course implements Attendable{
	
	public Practice(String courseCode, String name, String professor){
		super(courseCode,name,professor);
	}
	
	public int getLean(){
		return 90;
	}
	
	public boolean isAttendanceMandatory(){
		return true;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this){
			return true;
		}
		if(o == null){
			return false;
		}
		if(o.getClass().equals(this.getClass())){
			Practice l = (Practice)o;
			return l.getCourseCode() == super.getCourseCode();
		}
		else{
			return false;
		}
	}
	
	@Override
	public int hashCode(){
		return super.getCourseCode().hashCode()*100;
	}
	
	@Override
	public String toString(){
		return super.toString() + "{Gyakorlat}";
	}
}