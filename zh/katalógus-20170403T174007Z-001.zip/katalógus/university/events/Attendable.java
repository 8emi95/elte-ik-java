package university.events;

public interface Attendable{
	
	public int getLean();
	public boolean isAttendanceMandatory();
}