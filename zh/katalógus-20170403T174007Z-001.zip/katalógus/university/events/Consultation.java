package university.events;

public class Consultation extends Course implements Attendable{
	
	public Consultation(String courseCode, String name, String professor){
		super(courseCode,name,professor);
	}
	
	public int getLean(){
		return 15;
	}
	
	public boolean isAttendanceMandatory(){
		return false;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this){
			return true;
		}
		if(o == null){
			return false;
		}
		if(o.getClass().equals(this.getClass())){
			Consultation l = (Consultation)o;
			return l.getCourseCode() == super.getCourseCode();
		}
		else{
			return false;
		}
	}
	
	@Override
	public int hashCode(){
		return super.getCourseCode().hashCode()*1000;
	}
	
	@Override
	public String toString(){
		return super.toString() + "{Konzultáció}";
	}
}