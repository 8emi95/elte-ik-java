package university.events;

public class OfficeHour implements Attendable{
	
	private final String professor;
	
	public OfficeHour(String professor){
		this.professor = professor;
	}
	
	public String getProfessor(){
		return professor;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this){
			return true;
		}
		if(o == null){
			return false;
		}
		if(o.getClass() != this.getClass()){
			return false;
		}
		else{
			OfficeHour oh = (OfficeHour)o;
			return oh.getProfessor().equals(this.getProfessor());
		}
	}
	
	@Override
	public int hashCode(){
		return professor.hashCode();
	}
	
	public int getLean(){
		return 5;
	}
	
	public boolean isAttendanceMandatory(){
		return false;
	}
	
	@Override
	public String toString(){
		return professor + "{Fogadóóra}";
	}
}