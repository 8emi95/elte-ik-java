package university.events;

public class FacultyDay{}