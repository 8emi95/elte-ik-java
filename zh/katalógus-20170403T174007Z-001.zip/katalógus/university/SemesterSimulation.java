package university;
import university.events.*;
import university.entities.*;
import java.util.*;

public class SemesterSimulation{
	private final Cabinet cabinet = new Cabinet();
	private final LinkedList<Student> students = new LinkedList<Student>();
	
	private HashMap<String, String> _courses;
	private HashMap<String, String> _students;
	
	
	public void prepareCourses(Map<String, String> m){
		/*
		_courses = new HashMap(m);
		for(HashMap.Entry<String, String> entry : _courses.entrySet()){
			String flags = entry.getKey().substring(1, entry.getKey().indexOf(']'));
			String name = entry.getKey().substring(entry.getKey().indexOf(']')+1, entry.getKey().indexOf('('));
			String code = entry.getKey().substring(entry.getKey().indexOf('(')+1, entry.getKey().length-1);
			
			String prof = null;
			if(flags.contains("L")){
				_courses.put(new Lecture(code, name, prof));
			}
			if(flags.contains("P")){
				_courses.put(new Practice(code, name, prof));				
			}
			if(flags.contains("C")){
				_courses.put(new Consultation(code, name, prof));				
			}
		}
		*/
	}
	
	public void prepareStudents(Map<String, String> m){
		for(HashMap.Entry<String, String> entry : _courses.entrySet()){
			String[] stdata = entry.getKey().split(",");
			String name = stdata[0];
			String neptun = stdata[1];
			if(stdata.length==4){
				int spirit = Integer.parseInt(stdata[2]);
				int sloth = Integer.parseInt(stdata[3]);
				students.add( new Student(name, neptun, spirit, sloth));
			}
			else{
				students.add(new Student(name, neptun));
			}
			
			String[] crsdata = entry.getValue().split("|");
			
			
		}			
	}			
	
	public void process(){
		for(int i = 0;i<15*5;++i){
			int dobas  = new Random().nextInt(100)+1;
			if(dobas==100) continue;
			
			if(dobas>95){
				for(Student s : students){
					if(s.hasAttendanceDesire(new FacultyDay() )){
						cabinet.registerBonus(s);
					}
				}
			}
			else{
				
			}
		}
		
		for(Student s : students){
			System.out.println(s.getName()+","+s.getNeptun()+"," + cabinet.getMissesFor(s));
		}
	}
}