package university;

import java.util.HashSet;
import java.lang.StringBuilder;
import university.entities.*;

public class Roster<T>{
	
	private T event;
	private int day;
	private HashSet<Student> roster;
	
	public Roster(T event, int day, int size){
		this.event = event;
		this.day = day;
		roster = new HashSet<>(size);
	}
	
	public boolean hasAttended(Student s){
		for(Student st : roster){
			if(st.equals(s)){
				return true;
			}
		}
		return false;
	}
	
	public void attend(Student s){
		roster.add(s);
	}
	
	public T getEvent(){
		return event;
	}
	
	public int getDay(){
		return day;
	}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(event);
		sb.append("/");
		sb.append(day);
		sb.append(":");
		for(Student s : roster){
			sb.append("\n");
			sb.append(s.getName());
			sb.append(",");
			sb.append(s.getNeptun());
		}
		return sb.toString();
	}
}