package university.entities;

public class Student{
	
	private final String name;
	private final String neptun;
	private final int spirit;
	private final int sloth;
	
	public Student(String name, String neptun){
		this.name = name;
		this.neptun = neptun;
		spirit = 75;
		sloth = 50;
	}
	
	public Student(String name, String neptun, int spirit, int sloth){
		this.name = name;
		this.neptun = neptun;
		if(spirit<0 || spirit>100){
			throw new IllegalArgumentException("0 és 100 közötti értéknek kell lennie");
		}
		else{
			this.spirit = spirit;
		}
		if(sloth<0 || sloth>100){
			throw new IllegalArgumentException("0 és 100 közötti értéknek kell lennie");
		}
		else{
			this.sloth = sloth;
		}
	}
	
	public Student(Student s){
		name = s.name;
		neptun = s.neptun;
		spirit = s.spirit;
		sloth = s.sloth;
	}
	
	public String getName(){
		return name;
	}
	
	public String getNeptun(){
		return neptun;
	}
	
	public int getSpirit(){
		return spirit;
	}
	
	public int getSloth(){
		return sloth;
	}
	
	@Override
	public String toString(){
		return name + "{" + neptun + "}(" + spirit + "|" + sloth + ")";
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this){
			return true;
		}
		if(o == null){
			return false;
		}
		if(o.getClass() != this.getClass()){
			return false;
		}
		else{
			Student s = (Student)o;
			return s.neptun.equals(this.neptun);
		}
	}
	
	@Override
	public int hashCode(){
		return neptun.hashCode();
	}
	
	
	
}