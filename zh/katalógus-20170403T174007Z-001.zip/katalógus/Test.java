import tests.*;

// Sometimes, you need just one another layer of wrappers...

public class Test {
  public static void main(String[] args) {
    tests.Test.main(args);
  }

  private static void _References() {
    // Hivatkozunk a teszt-osztályokra, hogy a fordító mindenképpen lefordítsa a teljes csomagot.
    {
      TestStudent ts;
	  TestAttendable ta;
      TestCourse tc;
      TestLecture tl;
      TestPractice tp;
      TestConsultation tco;
      TestCourse_EqualityXTypes tce;
      TestOfficeHour toh;
      TestFacultyDay tfd;
      TestRoster tr;
      // TestCabinet tcab;
      // TestCabinet_getMissesFor tcabGMF;
      // TestStudent_Desire tsd;
      // TestSemesterSimulation_Prepare tsspre;
      // TestSemesterSimulation_Process tsspro;
    }
  }
}
