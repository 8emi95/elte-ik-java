package tests;

import graph.Graph;
import entities.*;

import utest.*;
import java.lang.Object;

public class Part2GraphTest extends Testable {
	
	@Override
    public void assertion() {
		// Nincs mit tesztelni. Ha az interfesz rendelkezik a megfelelo deklaralt metodusokkal, akkor helyes.
    }

    @Override
	public String description() {
		return getClass().getName();
	}
    
	@Override
	public String className() { 
		return "graph.Graph"; 
	}

	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {};
	}
	
	@Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			method(Boolean.TYPE, className() + ".hasEdge", Entity.class, Entity.class)
		    , method(Void.TYPE, className() + ".addNode", Entity.class)
		    , method(Void.TYPE, className() + ".addEdge", Entity.class, Entity.class)
		
		};
		
    }
    
	@Override
	public int score() {  
		return 2; 
	}
    
    public static void main(String... args) {
        Test.main(new Part2GraphTest());
    }
}