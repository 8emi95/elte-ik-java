package tests;

import utils.Genre;
import utest.*;
import java.lang.reflect.Method;
import java.util.Arrays;

public class Part1GenreTest extends Testable {
	
	@Override
    public void assertion() {
		check("A mufajok nem a megfelelo sorrendben vannak definialva.", 
		Genre.ACTION.ordinal() == 0 && Genre.ADVENTURE.ordinal() == 1 && Genre.COMEDY.ordinal() == 2 &&  Genre.CRIME.ordinal() == 3 && Genre.DRAMA.ordinal() == 4);
	
    }

    @Override
	public String description() {
		return getClass().getName();
	}
	
	@Override
    public String className() { 
		return "utils.Genre"; 
	}
	
	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {
				staticField(className() + ".ACTION"),
				staticField(className() + ".ADVENTURE"),
				staticField(className() + ".COMEDY"),
				staticField(className() + ".CRIME"),
				staticField(className() + ".DRAMA")
		};
	}
	
	@Override
	public Object[] expectedMethods() throws Exception {
		Method[] baseMethods = Enum.class.getMethods();
		Object[] methods = Arrays.copyOfRange(baseMethods, 0, baseMethods.length + 5, Object[].class);
		methods[baseMethods.length] = method(String.class, className() + ".toString");
		methods[baseMethods.length + 1] = method(Genre[].class, className() + ".values");
		methods[baseMethods.length + 2] = method(Genre.class, className() + ".valueOf", String.class);
		return methods;
	}

	@Override
	public int score() {
		return 1;
	}

    public static void main(String... args) {
        Test.main(new Part1GenreTest());
    }
}
