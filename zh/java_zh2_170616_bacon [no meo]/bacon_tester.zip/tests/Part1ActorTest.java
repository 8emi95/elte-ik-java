package tests;

import utest.*;
import entities.*;
import utils.Genre;

public class Part1ActorTest extends Testable {
	
	@Override
    public void assertion() {
		
		check("Az osztaly nem implementalja a Comparable<Actor> interfeszt.",doesImplementInterface(className(), Comparable.class));
		
		Actor a1 = new Actor("Kevin Bacon");
        check("Actor(): nem hozza letre az objektumot.", a1 != null);		
		check("getName(): a metodus nem a helyes nevet adja vissza.", a1.getName().equals("Kevin Bacon"));
		Actor a2 = new Actor("Kevin Bacon");
		Actor a3 = new Actor("Matt Damon");
		
		Movie m1 = new Movie("Titanic",Genre.DRAMA,1997);
		
		check("compareTo(): a metodus rosszul hasonlit ossze azonos nevu szineszeket (a1,a2).", a1.compareTo(a2)==0);
		check("compareTo(): a metodus rosszul hasonlit ossze azonos nevu szineszeket (a2,a1).", a2.compareTo(a1)==0);
		
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo nevu szineszeket (a1,a3).", a1.compareTo(a3)<0);
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo nevu szineszeket (a3,a1).", a3.compareTo(a1)>0);
		
		check("equals(): a metodus hibasan mukodik null objektum eseten.", !a1.equals(null));
		check("equals(): a metodus hibasan mukodik mas tipusu objektum eseten.", !a1.equals(m1));
		check("equals(): a metodus hamissal ter vissza azonos szineszek eseten (a1, a2 = Kevin Bacon).", a1.equals(a2));
		check("equals(): a metodus hamissal ter vissza azonos szineszek eseten (a2, a1 = Kevin Bacon).", a2.equals(a1));
		check("equals(): a metodus igazzal ter vissza kulonbozo szineszek eseten (a1,a3).", !a1.equals(a3));
		check("equals(): a metodus igazzal ter vissza kulonbozo szineszek eseten (a3,a1).", !a3.equals(a1));
		
		check("hashCode(): a metodus nem a helyes hasitokodot adja vissza.", a1.hashCode()==a2.hashCode());
		check("toString(): a metodus nem a helyes szoveges reprezentaciot adja vissza (Kevin Bacon).", a1.toString().equals("Kevin Bacon"));
	
    }

    @Override
	public String description() {
		return getClass().getName();
	}
    
	@Override
	public String className() { 
		return "entities.Actor"; 
	}

	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {};
	}
	
	@Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			constructor(className(), new Class[] {String.class})
			, method(String.class, className() + ".getName")
			, method(Integer.TYPE, className() + ".compareTo", Object.class)
			, method(Integer.TYPE, className() + ".compareTo", Actor.class)
			, method(Boolean.TYPE, className() + ".equals", Object.class)
			, method(Integer.TYPE, className() + ".hashCode")
			, method(String.class, className() + ".toString")
		};
		
    }
	
	@Override
	public int score() {  
		return 4; 
	}
    
    public static void main(String... args) {
        Test.main(new Part1ActorTest());
    }
}