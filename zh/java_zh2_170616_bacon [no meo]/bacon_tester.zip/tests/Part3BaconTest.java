package tests;

import utest.*;
import java.io.*;

import bacon.Bacon;
import entities.Actor;

public class Part3BaconTest extends Testable {
	
	@Override
    public void assertion() throws IOException{
		Bacon b = new Bacon("imdb.txt");
		check("Bacon(): a konstruktor nem hozza letre az objektumot.", b != null);	
		
		Actor a1 = new Actor("Kate Winslet"); 
		Actor a2 = new Actor("Julia Roberts"); 
		Actor a3 = new Actor("Kevin Bacon"); 
		
		check("simulate(): a metodus nem jol vegzi a szimulaciot a1-bol (Kate Winslet) inditva.", b.simulate(a1).equals("Kate Winslet's number is 2.\nKevin Bacon->Apollo 13 (ADVENTURE, 1995)->Bill Paxton->Titanic (DRAMA, 1997)->Kate Winslet"));
		check("simulate(): a metodus nem jol vegzi a szimulaciot a2-bol (Julia Roberts) inditva.", b.simulate(a2).equals("Julia Roberts's number is 1.\nKevin Bacon->Flatliners (DRAMA, 1990)->Julia Roberts"));
		check("simulate(): a metodus nem jol vegzi a szimulaciot a3-bol (Kevin Bacon) inditva.", b.simulate(a3).equals("Kevin Bacon's number is 0.\nKevin Bacon"));

    }

    @Override
	public String description() {
		return getClass().getName();
	}
	
	@Override
    public String className() { 
		return "bacon.Bacon"; 
	}
	
	@Override
	public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }
	
	
	@Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			constructor(className(), new Class[] {String.class})
			, method(String.class, className() + ".simulate", Actor.class)
		};
		
    }
	
	@Override
	public int score() {
		return 5;
	}

    public static void main(String... args) {
        Test.main(new Part3BaconTest());
    }
}
