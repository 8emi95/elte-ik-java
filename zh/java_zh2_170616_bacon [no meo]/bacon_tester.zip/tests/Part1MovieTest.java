package tests;

import utest.*;
import entities.*;
import utils.Genre;

public class Part1MovieTest extends Testable {
	
	@Override
    public void assertion() {
		
		check("Az osztaly nem implementalja a Comparable<Movie> interfeszt.",doesImplementInterface(className(), Comparable.class));
		
		Actor a1 = new Actor("Kevin Bacon");
		
		Movie m1 = new Movie("Titanic",Genre.DRAMA,1997);
        check("Movie(): nem hozza letre az objektumot.", m1 != null);		
		check("getName(): a metodus nem a helyes cimet adja vissza.", m1.getName().equals("Titanic"));
		
		Movie m2 = new Movie("Titanic",Genre.DRAMA,1997);
		Movie m3 = new Movie("Titanic",Genre.COMEDY,1997);
		Movie m4 = new Movie("Titanic",Genre.DRAMA,2000);
		Movie m5 = new Movie("Apollo 13",Genre.ADVENTURE,1995);
		
		check("compareTo(): a metodus rosszul hasonlit ossze azonos filmeket (m1,m2).", m1.compareTo(m2)==0);
		check("compareTo(): a metodus rosszul hasonlit ossze azonos filmeket (m2,m1).", m2.compareTo(m1)==0);
		
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m1,m3).", m1.compareTo(m3)>0);
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m3,m1).", m3.compareTo(m1)<0);
		
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m1,m4).", m1.compareTo(m4)<0);
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m4,m1).", m4.compareTo(m1)>0);
		
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m1,m5).", m1.compareTo(m5)>0);
		check("compareTo(): a metodus rosszul hasonlit ossze kulonbozo filmeket (m5,m1).", m5.compareTo(m1)<0);
		
		check("equals(): a metodus hibasan mukodik null objektum eseten.", !m1.equals(null));
		check("equals(): a metodus hibasan mukodik mas tipusu objektum eseten.", !m1.equals(a1));
		check("equals(): a metodus hamissal ter vissza azonos filmek eseten (m1, m2).", m1.equals(m2));
		check("equals(): a metodus hamissal ter vissza azonos filmek eseten (m2, m1).", m2.equals(m1));
		
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m1,m3).", !m1.equals(m3));
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m3,m1).", !m3.equals(m1));
		
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m1,m4).", !m1.equals(m4));
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m4,m1).", !m4.equals(m1));
		
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m1,m4).", !m1.equals(m5));
		check("equals(): a metodus igazzal ter vissza kulonbozo filmek eseten (m4,m1).", !m5.equals(m1));
		
		check("hashCode(): a metodus nem a helyes hasitokodot adja vissza.", m1.hashCode()==m2.hashCode());
	
		check("toString(): a metodus nem a helyes szoveges reprezentaciot adja vissza (Titanic (DRAMA, 1997)).", m1.toString().equals("Titanic (DRAMA, 1997)"));
	
    }

    @Override
	public String description() {
		return getClass().getName();
	}
    
	@Override
	public String className() { 
		return "entities.Movie"; 
	}

	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {};
	}
	
	@Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			constructor(className(), new Class[] {String.class, Genre.class, Integer.TYPE})
			, method(String.class, className() + ".getName")
			, method(Integer.TYPE, className() + ".compareTo", Object.class)
			, method(Integer.TYPE, className() + ".compareTo", Movie.class)
			, method(Boolean.TYPE, className() + ".equals", Object.class)
			, method(Integer.TYPE, className() + ".hashCode")
			, method(String.class, className() + ".toString")
		};
		
    }
	
	@Override
	public int score() {  
		return 6; 
	}
    
    public static void main(String... args) {
        Test.main(new Part1MovieTest());
    }
}