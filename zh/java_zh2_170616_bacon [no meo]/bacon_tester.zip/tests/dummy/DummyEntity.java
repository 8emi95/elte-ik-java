package tests.dummy;

import entities.Entity;

public class DummyEntity extends Entity{
		
	public DummyEntity(String name) {
		super(name);
	}
	
}