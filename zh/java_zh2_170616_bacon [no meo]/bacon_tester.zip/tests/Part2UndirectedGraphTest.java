package tests;

import graph.Graph;
import graph.undirected.UndirectedGraph;
import entities.*;
import utils.Genre;

import java.util.*;

import utest.*;
import java.lang.Object;

public class Part2UndirectedGraphTest extends Testable {
	
	@Override
    public void assertion() {
		check("Az osztaly nem implementalja a generikus Graph interfeszt.",doesImplementInterface(className(), Graph.class));
		
		UndirectedGraph<Entity> uG = new UndirectedGraph<Entity>();
		
		check("UndirectedGraph(): helyes parameterekkel sem hozza letre az objektumot.", uG != null);
		
		Movie m1 = new Movie("A Few Good Men",Genre.DRAMA,1992);
		Actor a11 = new Actor("Tom Cruise");
		Actor a12 = new Actor("Jack Nicholson");
		Actor a13 = new Actor("Demi Moore");
		Actor a14 = new Actor("Kevin Bacon");
		
		try {
			check("hasEdge(): a metodus nem helyes eredmenyt ad vissza ures (csucsokat es eleket nem tartalmazo) graf eseten.", uG.hasEdge(m1, a11)==false);
		} catch (NoSuchElementException e) {	
		}
		
		uG.addEdge(m1,a11);
		check("hasEdge(): a metodus nem helyes eredmenyt ad vissza, ha ket csucs kozott van el.", uG.hasEdge(m1, a11)==true);
		check("hasEdge(): a metodus nem helyes eredmenyt ad vissza, ha ket csucs kozott van el.", uG.hasEdge(a11, m1)==true);
		
		uG.addEdge(m1,a12);
		uG.addEdge(m1,a13);
		uG.addEdge(m1,a14);
		
		Movie m2 = new Movie("Animal House",Genre.COMEDY,1978);
		Actor a21 = new Actor("John Belushi");
		Actor a22 = new Actor("Karen Allen");
		Actor a23 = new Actor("Donald Sutherland");
		uG.addEdge(m2,a21);
		uG.addEdge(m2,a22);
		check("hasEdge(): a metodus nem helyes eredmenyt ad vissza, ha ket csucs kozott van el.", uG.hasEdge(m1, a12)==true);
		uG.addEdge(m2,a23);
		uG.addEdge(m2,a14);
		
		Movie m3 = new Movie("Cold Mountain",Genre.ADVENTURE,2003);
		Actor a31 = new Actor("Jude Law");
		Actor a32 = new Actor("Nicole Kidman");
		Actor a33 = new Actor("Renée Zellweger");
		uG.addEdge(m3,a31);
		uG.addEdge(m3,a32);
		uG.addEdge(m3,a33);
		uG.addEdge(m3,a23);
		
		uG.bfs(a14);
		
		check("bfs(): a metodus nem jol vegzi a szelessegi keresest (Nicole Kidman).", uG.pathTo(a32).equals("Nicole Kidman's number is 2.\nKevin Bacon->Animal House (COMEDY, 1978)->Donald Sutherland->Cold Mountain (ADVENTURE, 2003)->Nicole Kidman"));
		check("bfs(): a metodus nem jol vegzi a szelessegi keresest (Kevin Bacon).", uG.pathTo(a14).equals("Kevin Bacon's number is 0.\nKevin Bacon"));
		
    }

    @Override
	public String description() {
		return getClass().getName();
	}
    
	@Override
	public String className() { 
		return "graph.undirected.UndirectedGraph"; 
	}

	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {};
	}
	
	@Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			constructor(className(), new Class[] {})
			, method(Boolean.TYPE, className() + ".hasEdge", Entity.class, Entity.class)
		    , method(Void.TYPE, className() + ".addNode", Entity.class)
		    , method(Void.TYPE, className() + ".addEdge", Entity.class, Entity.class)
			, method(Void.TYPE, className() + ".bfs", Entity.class)
			, method(Integer.TYPE, className() + ".distTo", Entity.class)
			, method(String.class, className() + ".pathTo", Entity.class)
		};
		
    }
	
	@Override
	public int score() {  
		return 12; 
	}
    
    public static void main(String... args) {
        Test.main(new Part2UndirectedGraphTest());
    }
}