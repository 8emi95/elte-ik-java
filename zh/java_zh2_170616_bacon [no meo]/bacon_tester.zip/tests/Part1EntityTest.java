package tests;

import tests.dummy.DummyEntity;

import utest.*;

public class Part1EntityTest extends Testable {
    
	@Override
	public void assertion() {
		check("Az Entity nem absztrakt osztaly.", isAbstractClass(className()));
		
		DummyEntity dE = new DummyEntity("Kevin Bacon");
		check("Entity(): nem hozza letre az objektumot.", dE != null);
		check("getName(): a metodus nem a helyes nevet adja vissza.", dE.getName().equals("Kevin Bacon"));
	
    }

    @Override
	public String description() {
		return getClass().getName();
	}
    
	@Override
	public String className() { 
		return "entities.Entity"; 
	}
	
	@Override
	public Object[] expectedFields() throws Exception {
		return new Object[] {};
	}
	
    @Override
    public Object[] expectedMethods() throws Exception {
        return new Object[]
		{   
			constructor(className(), new Class[] {String.class})
			, method(String.class, className() + ".getName")
		};
		
    }
	
	@Override
	public int score() {  return 1; }
    
    public static void main(String... args) {
        Test.main(new Part1EntityTest());
    }
}