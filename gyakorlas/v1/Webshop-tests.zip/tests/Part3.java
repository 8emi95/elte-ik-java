package tests;


import item.Book;
import item.Movie;
import shop.WebShop;
import utest.Test;
import utest.Testable;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Part3 extends Testable {
    public void assertion() throws CloneNotSupportedException {

        Book b1 = Book.makeBook("30;J. R. R. Tolkien;The Lord of the Rings;1949;10;Fantasy Action".split(";")) ;
        //System.out.println(b1);

        Book b2 = Book.makeBook("30;J. R. R. Tolkien;The Lord of the Rings;1949;10;Fantasy Action".split(";")) ;
        //System.out.println(b2);

        WebShop ws = new WebShop("input.txt");

        check("WebShop.getOrderedItems(): nem megfelelő a rendezett set kiírása",like(ws.getOrderedItems().trim(),"Items: [Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Action, Fantasy] Amount on stock: 5], Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Action, Fantasy] Amount on stock: 8], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 10], Book [Andy Weir: The Martian (Year: 2011) Tags: [Satire, Action, Sci_fi] Amount on stock: 5], Movie [Ridley Scott: The Martian (Year: 2015) Tags: [Action, Sci_fi] Amount on stock: 10]]".trim()));

    }
    public static boolean like(String expected, String actual) {

        String[] s1 = expected.split("\\[|\\]|,|\\-| ");
        String[] s2 = actual.split("\\[|\\]|,|\\-| ");
        HashMap<String,Integer> s1m = new HashMap<>();
        HashMap<String,Integer> s2m = new HashMap<>();

        for(String s : s1)
        {
            if(!s.equals(" ")) {
                if (s1m.containsKey(s))
                    s1m.put(s, s1m.get(s) + 1);
                else
                    s1m.put(s, 1);
            }

        }
        for(String s : s2)
        {
            if(!s.equals(" ")) {
                if (s2m.containsKey(s))
                    s2m.put(s, s2m.get(s) + 1);
                else
                    s2m.put(s, 1);
            }

        }
        for(Map.Entry<String,Integer> e: s1m.entrySet())
        {
            if(!s2m.containsKey(e.getKey())) {
                System.out.println("Hiány");
                System.out.println(e.getKey());

            }else
            if(!s2m.get(e.getKey()).equals(e.getValue()))
                return false;

        }
        return  true;

    }
    public String description() { return "3. resz"; }
   // public String className() { return "rental.Car"; }

    public Object[] expectedMethods() throws Exception {
        return new Object[1]
              ;
    }


    public Object[] expectedFields() throws Exception {
        return new Object[1]
             ;
    }


    public static void main(String... args) {
        Test.main(new Part3());
    }
}