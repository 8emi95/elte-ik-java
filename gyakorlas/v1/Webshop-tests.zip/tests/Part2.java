package tests;


import shop.WebShop;
import utest.*;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Part2 extends Testable {
    public void assertion() throws CloneNotSupportedException {

        WebShop ws = new WebShop("input.txt");

        check("WebShop.WebShop(): nem tárolt le minden ügyfelet.", ws.getCustomersCount()== 3);
        check("WebShop.WebShop(): nem tárolt le minden itemet.", ws.getItemsCount()== 8);
        check("WebShop.printItems(): nem a megfelelő formátumban adja vissza az elemeket, vagy hiba a beolvasásnál, esetleg az eladásnál.", like(ws.printItems().trim(),"Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Movie [Ridley Scott: The Martian (Year: 2015) Tags: [Action, Sci_fi] Amount on stock: 10], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 10], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [Andy Weir: The Martian (Year: 2011) Tags: [Satire, Action, Sci_fi] Amount on stock: 5], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]".trim()));
        //System.out.println(ws.getMostLikedItem());
        //System.out.println(ws.blackFriday());


    }

    public static boolean like(String expected, String actual) {

        String[] s1 = expected.split("\\[|\\]|,|\\-| ");
        String[] s2 = actual.split("\\[|\\]|,|\\-| ");
        HashMap<String,Integer> s1m = new HashMap<>();
        HashMap<String,Integer> s2m = new HashMap<>();

        for(String s : s1)
        {
            if(!s.equals(" ")) {
                if (s1m.containsKey(s))
                    s1m.put(s, s1m.get(s) + 1);
                else
                    s1m.put(s, 1);
            }

        }
        for(String s : s2)
        {
            if(!s.equals(" ")) {
                if (s2m.containsKey(s))
                    s2m.put(s, s2m.get(s) + 1);
                else
                    s2m.put(s, 1);
            }

        }
        for(Map.Entry<String,Integer> e: s1m.entrySet())
        {
            if(!s2m.containsKey(e.getKey())) {
                System.out.println("Hiány");
                System.out.println(e.getKey());

            }else
            if(!s2m.get(e.getKey()).equals(e.getValue()))
                return false;

        }
        return  true;

    }
    public String description() { return "2. resz"; }
    //public String className() { return "rental.Car"; }

    /* Expected methods. */
    public Object[] expectedMethods() throws Exception {
        return new Object[] {};
    }

    /* Expected fields. */
    public Object[] expectedFields() throws Exception {
        return new Object[] {};
    }

    public static void main(String... args) {
        Test.main(new Part2());
    }
}