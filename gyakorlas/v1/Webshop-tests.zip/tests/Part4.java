package tests;


import shop.WebShop;
import utest.Test;
import utest.Testable;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Part4 extends Testable {
    public void assertion() throws CloneNotSupportedException {

        WebShop ws = new WebShop("input.txt");

        ws.saveState();
        ws.addPurchase(new String[]{"John Doe","Alien"});
        ws.saveState();

        check("WebShop.toString() : nem megfelelő a kiírás formátuma", like(ws.toString().trim(),"WebShop: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Movie [Ridley Scott: The Martian (Year: 2015) Tags: [Action, Sci_fi] Amount on stock: 10], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 9], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [Andy Weir: The Martian (Year: 2011) Tags: [Satire, Action, Sci_fi] Amount on stock: 5], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]; Customers: [Customer: [John DoeTwo, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]], Customer: [Gipsz Jakab, Istókhalma]: [Items: [Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]], Customer: [John Doe, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 9], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2]]]]]".trim()));
        check("WebShop.printHistory(): hibás kiírás vagy clone",like(ws.printHistory().trim(),"WebShop: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Movie [Ridley Scott: The Martian (Year: 2015) Tags: [Action, Sci_fi] Amount on stock: 10], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 10], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [Andy Weir: The Martian (Year: 2011) Tags: [Satire, Action, Sci_fi] Amount on stock: 5], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]; Customers: [Customer: [John Doe, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2]]], Customer: [John DoeTwo, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]], Customer: [Gipsz Jakab, Istókhalma]: [Items: [Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]]]]\n" +
                "-WebShop: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Movie [Ridley Scott: The Martian (Year: 2015) Tags: [Action, Sci_fi] Amount on stock: 10], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 9], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [Andy Weir: The Martian (Year: 2011) Tags: [Satire, Action, Sci_fi] Amount on stock: 5], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]; Customers: [Customer: [John DoeTwo, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]], Customer: [Gipsz Jakab, Istókhalma]: [Items: [Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2], Book [J. R. R. Tolkien: The Lord of the Rings (Year: 1949) Tags: [Fantasy, Action] Amount on stock: 8]]], Customer: [John Doe, New York]: [Items: [Book [Jean-Paul Sartre: La nausée (Year: 1938) Tags: [Philosophy] Amount on stock: 4], Book [J. R. R. Tolkien: The Hobbit (Year: 1937) Tags: [Fantasy, Action] Amount on stock: 5], Movie [Ridley Scott: Alien (Year: 1979) Tags: [Action, Sci_fi] Amount on stock: 9], Movie [Ridley Scott: The Martian(the movie) (Year: 2015) Tags: [Satire, Action, Sci_fi] Amount on stock: 7], Book [Joseph Heller: Catch-22 (Year: 1961) Tags: [Satire, Action] Amount on stock: 2]]]]]".trim()));

    }

    public String description() { return "4. resz"; }
    //public String className() { return "rental.Car"; }

    public Object[] expectedMethods() throws Exception {
        return new Object[1]
               /* { constructor(className(), new Class[] {String.class, String.class, Double.TYPE})
                        , staticMethod(className() + ".make", String.class, String.class, Double.TYPE)
                        , staticMethod(className() + ".validLicensePlate", String.class)
                        , method(className() + ".getPrice")
                        , method(className() + ".decreasePrice")
                        , method(className() + ".cheaperThan", rental.Car.class)
                        , method(className() + ".toString")
                }*/;
    }


    public Object[] expectedFields() throws Exception {
        return new Object[1]
                /*{ staticField(className() + ".MAX_PRICE")
                        , staticField(className() + ".CAR_OF_THE_YEAR")
                }*/;
    }

    public static boolean like(String expected, String actual) {

        String[] s1 = expected.split("\\[|\\]|,|\\-| ");
        String[] s2 = actual.split("\\[|\\]|,|\\-| ");
        HashMap<String,Integer> s1m = new HashMap<>();
        HashMap<String,Integer> s2m = new HashMap<>();

        for(String s : s1)
        {
            if(!s.equals(" ")) {
                if (s1m.containsKey(s))
                    s1m.put(s, s1m.get(s) + 1);
                else
                    s1m.put(s, 1);
            }

        }
        for(String s : s2)
        {
            if(!s.equals(" ")) {
                if (s2m.containsKey(s))
                    s2m.put(s, s2m.get(s) + 1);
                else
                    s2m.put(s, 1);
            }

        }
        for(Map.Entry<String,Integer> e: s1m.entrySet())
        {
            if(!s2m.containsKey(e.getKey())) {
                System.out.println("Hiány");
                System.out.println(e.getKey());

            }else
            if(!s2m.get(e.getKey()).equals(e.getValue()))
               return false;

        }
        return  true;

    }


    public static void main(String... args) {
        Test.main(new Part4());
    }
}