package tests;


import customer.Customer;
import item.Book;
import item.Item;
import item.Movie;
import item.Tag;
import utest.*;

import java.io.File;
import java.util.Set;

public class Part1 extends Testable {
    @Override
    public String description() {
        return null;
    }

    public void assertion() throws CloneNotSupportedException {
      //  System.out.println(new File("").getAbsolutePath());
       // WebShop ws = new WebShop("input.txt");
       // System.out.println("----Items----");
       // System.out.println(Tag.values().toString());


        Set<Tag> s = Item.readTags("Sci_fi Action Fantasy Romantic Philosophy Satire");
        check("Tagak beolvasása nem működik",s.size()==Tag.values().length);
        Book b = Book.makeBook("12;Andy Weir;The Martian;2011;5; Sci_fi Action Satire".split(";"));
        check("Book.makeBook(): Jó adatokkal sem hozza létre az objektumot.", b != null);
        Book b1 = Book.makeBook("12.;Andy Weir;The Martian;2011;5; Sci_fi Action Satire".split(";"));
        check("Book.makeBook(): Hibás árnál is létrehozza az objektumot.", b1 == null);
        Book b2 = Book.makeBook("12;Andy346 Weir;The Martian;2011;5; Sci_fi Action Satire".split(";"));
        check("Book.makeBook(): Hibás névnél is létrehozza az objektumot.", b2 == null);
        Book b3 = Book.makeBook("12;Andy Weir;The Martian;2,011;5; Sci_fi Action Satire".split(";"));
        check("Book.makeBook(): Hibás évnél is létrehozza az objektumot.", b3 == null);

        //!!!!!
        //Book [Andy Weir: The Martian (Year: 2011) Tags: [Sci_fi, Action, Satire] Amount on stock: 5]

        //
        System.out.println(b);  // "Book [Andy Weir: The Martian (Year: 2011) Tags: [Sci_fi, Action, Satire] Amount on stock: 5]"
        check("A tagváltozók inicializációja vagy a toString nem működik",b.toString().startsWith("Book [Andy Weir: The Martian (Year: 2011)".trim()));

        Movie m = Movie.makeMovie("10;Ridley Scott;The Martian;2015;10; Sci_fi Action".split(";"));
        check("Book.makeBook(): Jó adatokkal sem hozza létre az objektumot.", m != null);
        Movie m1 = Movie.makeMovie("12.0;Ridley Scott;The Martian;2015;10; Sci_fi Action".split(";"));
        check("Book.makeBook(): Hibás árnál is létrehozza az objektumot.", m1 == null);
        Movie m2 = Movie.makeMovie("10;Ridley S457cott;The Martian;2015;10; Sci_fi Action".split(";"));
        check("Book.makeBook(): Hibás névnél is létrehozza az objektumot.", m2 == null);
        Movie m3 = Movie.makeMovie("10;Ridley Scott;The Martian;20.15;10; Sci_fi Action".split(";"));
        check("Book.makeBook(): Hibás évnél is létrehozza az objektumot.", m3 == null);
//!!!!!
        //System.out.println(m);
        check("A tagváltozók inicializációja vagy a toString nem működik",m.toString().startsWith("Movie [Ridley Scott: The Martian (Year: 2015) Tags: ".trim()));



        Customer c = Customer.makeCustomer("John Doe;New York".split(";"));
        check("Customer.makeCustomer(): Jó adatokkal sem hozza létre az objektumot.", c != null);
        Customer c4 = Customer.makeCustomer("J. R. R. Tolkien;New York".split(";"));
        check("Customer.makeCustomer(): Jó adatokkal sem hozza létre az objektumot.", c4 != null);//        ws.saveState();
        Customer c1 = Customer.makeCustomer("john Doe;New York".split(";"));
        check("Customer.makeCustomer(): Hibás névnél is létrehozza az objektumot.", c1 == null);//        ws.saveState();
        Customer c2 = Customer.makeCustomer("Jean-Paul Doe;New York".split(";"));
        check("Customer.makeCustomer(): Jó adatokkal sem hozza létre az objektumot.", c != null);//        ws.saveState();

    }



    public static void main(String... args) {
        Test.main(new Part1());
    }
}