﻿ELTE IK
Java
2016/2017 tavaszi félév
Poór Artór gyakorlatvezetőtől:
- órai feladatsorok és órai megoldások
- kiírt (nem kötelező) házi feladatok és megoldásaik

01. gyakorlat (Fordítás, futtatás, sor beolvasása, konvertálás számmá, elágazások, ciklusok)
02. gyakorlat (Osztályok, konstruktorok, metódusok, statikus adattagok és metódusok, tömbök)
03. gyakorlat (Tömbök, láncolt listák, Scanner)
04. gyakorlat (Többdimenziós tömbök, láncolt listák, túlterhelés)
05. gyakorlat (Fájl- és kivételkezelés alapjai)
06. gyakorlat (Interfészek, final)
07. gyakorlat (Öröklődés, osztályok kiterjesztése, rekurzió)
08. gyakorlat (Absztrakt ősosztályok, halmazok és vermek használata)
09. gyakorlat (Generikus osztályok, kivételosztály definiálása)
10. gyakorlat (equals, felsorolási típusok, absztrakt osztályok, Comparator)
11. gyakorlat (equals, hashCode, halmazok)
12. gyakorlat (Névtelen függények, Stream, Optional, Map)