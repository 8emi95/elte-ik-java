class AlreadyContainsException extends Exception {
    public AlreadyContainsException(String message) {
	super(message);
    }
}
