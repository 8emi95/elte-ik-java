class GreetingsA {
    public static void main(String[] args) {
        System.out.println("Szia! Hogy hivnak?");
        String name = System.console().readLine();
        System.out.println("Udv " + name + ", miujsag?");
    }
}
